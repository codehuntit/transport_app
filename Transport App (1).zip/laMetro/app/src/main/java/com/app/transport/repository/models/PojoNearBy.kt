package com.app.transport.repository.models

data class PojoNearBy(
    val code: Int,
    val currentTime: Long,
    val `data`: Data,
    val text: String,
    val version: Int
)

data class Data(
    val limitExceeded: Boolean,
    val list: List<NearBy>,
    val outOfRange: Boolean,
    val references: References
)

data class NearBy(
    val code: String,
    val direction: String,
    val id: String,
    val lat: Double,
    val locationType: Int,
    val lon: Double,
    val name: String,
    val routeIds: List<String>,
    val wheelchairBoarding: String
)

data class References(
    val agencies: List<Agency>,
    val routes: List<Route>,
    val situations: List<Any>,
    val stops: List<Any>,
    val trips: List<Any>
)

data class Agency(
    val disclaimer: String,
    val id: String,
    val lang: String,
    val name: String,
    val phone: String,
    val privateService: Boolean,
    val timezone: String,
    val url: String
)

data class Route(
    val agencyId: String,
    val color: String,
    val description: String,
    val id: String,
    val longName: String,
    val shortName: String,
    val textColor: String,
    val type: Int,
    val url: String
)