package com.app.transport.repository.interactors

import android.util.Log
import com.app.transport.repository.networkrequests.NetworkRequestCallbacks
import com.app.workforce.repository.networkrequests.RestClient
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.observers.DisposableObserver
import io.reactivex.schedulers.Schedulers
import retrofit2.Response

class GetEmploeyeIntrector {

    fun ongetEmployedata(
        networkRequestCallbacks: NetworkRequestCallbacks
    ): Disposable {
        return RestClient.get().getBusRoutes("","")
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(object : DisposableObserver<Response<*>>() {
                override fun onNext(response: Response<*>) {
                    Log.e("Intrector", "data" + "yes")
                    networkRequestCallbacks.onSuccess(response)
                }

                override fun onError(t: Throwable) {
                    networkRequestCallbacks.onError(t)
                    Log.e("EmployeModel", "data" + "No")
                }

                override fun onComplete() {

                }
            })
    }
}