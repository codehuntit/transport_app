package com.app.transport.views.adapters

import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.transport.R
import com.example.mvvmnewdemo.WithApiExample.model.EmployeData
import com.app.transport.base.inflate
import kotlinx.android.synthetic.main.load_data_layout.view.*

class EmployeeAdapter(firstDemofrag: Context) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val employeDataList = mutableListOf<EmployeData>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
  return  ListViewHolder(parent.inflate(R.layout.load_data_layout))
    }

    override fun getItemCount(): Int {
        return employeDataList.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {

        (holder as ListViewHolder).bindListView(employeDataList[i],i)

    }

    fun updatedata(list: List<EmployeData>) {
        employeDataList.clear()
        employeDataList.addAll(list)
        notifyDataSetChanged()

    }


    private inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindListView(
            employeData: EmployeData, i: Int) {


            itemView.txt_name.text=employeDataList.get(i).employee_name
            itemView.txt_age.text=employeDataList.get(i).employee_age
            itemView.txt_dalary.text=employeDataList.get(i).employee_salary

        }
    }
}