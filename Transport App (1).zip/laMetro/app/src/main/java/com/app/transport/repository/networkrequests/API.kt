package com.app.transport.repository.networkrequests

import com.app.transport.repository.models.PojoAlert
import com.app.transport.repository.models.PojoNearBy
import com.app.transport.repository.models.bus.PojoBusProdection
import com.app.transport.repository.models.bus.PojoBusRoutesList
import com.app.transport.repository.models.bus.PojoRouteDetailById
import com.app.transport.repository.models.rail.PojoMetroLine
import com.app.transport.repository.models.rail.PojoRailPrediction
import com.app.transport.repository.models.rail.PojoTrainRouteDetail
import com.example.mvvmnewdemo.WithApiExample.model.EmployeRespnseModel

import io.reactivex.Observable
import retrofit2.Response
import retrofit2.http.*

interface API {
    @GET
    fun getBusRoutes(
        @Header ("Authorization") Authorization:String,@Url
        url: String
    ): Observable<Response<PojoBusRoutesList>>

    @GET fun getBusRoutesDetail(
        @Url url: String
    ): Observable<Response<PojoRouteDetailById>>


    @GET fun getBusPredection(
        @Header ("Authorization") Authorization:String,

        @Url url: String
    ): Observable<Response<PojoBusProdection>>

    @GET fun nearBy(
        @Url url: String
    ): Observable<Response<PojoNearBy>>


    @GET fun getRailLine(
        @Header ("Authorization") Authorization:String,

        @Url url: String
    ): Observable<Response<PojoMetroLine>>



    @GET fun getRailRouteDetail(
        @Url url: String
    ): Observable<Response<PojoTrainRouteDetail>>


    @GET fun getRailPrediction(
        @Header ("Authorization") Authorization:String,
        @Url url: String
    ): Observable<Response<PojoBusProdection>>

    @GET fun alert(
        @Url url: String
    ): Observable<Response<PojoAlert>>


}