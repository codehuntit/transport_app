package com.app.transport.repository.models.rail

data  class PojoRailPrediction(
    val copyright: String,
    val predictions: List<Prediction>
)

data class Prediction(
    val agencyTitle: String,
    val dirTitleBecauseNoPredictions: String,
    val direction: Direction,
    val routeTag: String,
    val routeTitle: String,
    val stopTag: String,
    val stopTitle: String
)

data class Direction(
    val prediction: List<PredictionX>,
    val title: String
)

data class PredictionX(
    val affectedByLayover: String,
    val block: String,
    val dirTag: String,
    val epochTime: String,
    val isDeparture: String,
    val minutes: String,
    val seconds: String,
    val tripTag: String,
    val vehicle: String
)