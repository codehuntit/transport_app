package com.app.transport.views.activities

import android.util.Log
import android.view.View
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.app.transport.R
import com.app.transport.base.BaseActivity
import com.app.transport.databinding.ActivityBusDetailBinding
import com.app.transport.databinding.ActivityBusPredictionBinding
import com.app.transport.repository.models.favroites.FavData
import com.app.transport.repository.models.favroites.PojoFavroites
import com.app.transport.repository.preferences.UserPrefsManager
import com.app.transport.viewmodels.BaseViewModel
import com.app.transport.viewmodels.BusViewModel
import com.app.transport.views.adapters.BusDetailAdapter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.toolbar.*
import java.lang.reflect.Type


class BusPredictionActivity : BaseActivity(), View.OnClickListener {
    var binding: ActivityBusPredictionBinding? = null
    private val mBusDetailAdapter: BusDetailAdapter by lazy { BusDetailAdapter(this) }
    private val mBusViewModel by lazy { ViewModelProvider(this)[BusViewModel::class.java] }
    protected val mUserPrefsManager: UserPrefsManager by lazy { UserPrefsManager(getApplication()) }
    var favList = mutableListOf<FavData>()
    var isFav = false

    override fun getContentId(): Int {
        return R.layout.activity_bus_prediction
    }

    override val viewModel: BaseViewModel?
        get() = mBusViewModel

    override fun init() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_bus_prediction)

        ivToolbarRightIcon.visibility = View.VISIBLE
        toolbar.visibility = View.VISIBLE
        tvToolbarTitleSub.visibility = View.VISIBLE
        searchView.visibility = View.GONE
        ivToolbarLeftIcon.visibility = View.VISIBLE
        ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon1)
        tvToolbarTitle.text = intent.getStringExtra("StopName")
        tvToolbarTitleSub.text = "Stop Code: " + intent.getStringExtra("StopId")

        // set click listener
        ivToolbarLeftIcon.setOnClickListener(this)
        ivToolbarRightIcon.setOnClickListener(this)

        mBusViewModel.getBusPredection(intent.getStringExtra("StopId")!!)
        // set adapter
        binding!!.rvBusDetail.adapter = mBusDetailAdapter

        binding!!.swiperefresh.setOnRefreshListener {
            mBusViewModel.getBusPredection(intent.getStringExtra("StopId")!!)
            binding!!.swiperefresh.isRefreshing= false
        }
        if (mUserPrefsManager.getFavData() != null
        ) {
            var FavroiteList = mUserPrefsManager.getFavData()

            if (FavroiteList.data != null && FavroiteList.data.isNotEmpty()) {

                for (i in FavroiteList.data.indices) {

                    if (FavroiteList.data[i].stopID == intent.getStringExtra("StopId")) {
                        isFav = true
                    }
                }

            }
        }

        if (isFav) {
            ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon2)
        } else {
            ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon1)
        }

    }

    override fun observeProperties() {
        mBusViewModel.onGetBusPrediction().observe(this, Observer {
            binding!!.progress.visibility = View.GONE
            binding!!.tvNoData.text = "No Prediction Found"
            binding!!.tvNoData.visibility = View.VISIBLE
            if (it?.predictionsData!![0].destinations[0].predictions.isNotEmpty()) {
                binding!!.progress.visibility = View.GONE
                binding!!.tvNoData.visibility = View.GONE
                mBusDetailAdapter.updateData(it.predictionsData)
            } else {
                binding!!.tvNoData.text = "No Prediction Found"
                binding!!.tvNoData.visibility = View.VISIBLE
                binding!!.progress.visibility = View.GONE
            }
        })
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.ivToolbarRightIcon -> {
                if (isFav) {

                    if (mUserPrefsManager.getFavData() != null
                    ) {
                        var FavroiteList = mUserPrefsManager.getFavData()

                        if (FavroiteList.data != null && FavroiteList.data.isNotEmpty()) {
                            favList.clear()
                            favList.addAll(FavroiteList.data)
                            for (id in FavroiteList.data.indices) {

                                if (FavroiteList.data[id].stopID == intent.getStringExtra("StopId")) {
                                    favList.removeAt(id)
                                    val pojoFavroite = PojoFavroites(favList)

                                    mUserPrefsManager.saveFavroiteData(pojoFavroite)
                                }



                                ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon1)
                                isFav = false



                            }
                        }




                    }
                } else {


                ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon2)

                if (mUserPrefsManager.getFavData() != null
                ) {
                    var FavroiteList = mUserPrefsManager.getFavData()

                    if(FavroiteList.data!=null  && FavroiteList.data.isNotEmpty())
                    {
                        favList.clear()
                    favList.addAll(FavroiteList.data)
                    }
                }
                var favData = FavData(
                    intent.getStringExtra("StopId")!!, "bus",
                    intent.getStringExtra("StopName")!!,"#ffffff"
                )
                favList.add(favData)
                var pojoFavroite = PojoFavroites(favList)



                    isFav = true

                mUserPrefsManager.saveFavroiteData(pojoFavroite)

                Log.e("TAG", "onClick: " + mUserPrefsManager.getFavData())
            }}
            R.id.ivToolbarLeftIcon -> {

                finish()


            }
        }


    }


}