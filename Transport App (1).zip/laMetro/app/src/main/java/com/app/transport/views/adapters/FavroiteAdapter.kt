package com.app.transport.views.adapters

import android.content.Intent
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.app.transport.R
import com.app.transport.base.inflate
import com.app.transport.repository.models.favroites.FavData
import com.app.transport.views.activities.BusPredictionActivity
import com.app.transport.views.activities.RailPredictionActivity
import kotlinx.android.synthetic.main.row_fav.view.*

class FavroiteAdapter(var context: Fragment) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var mDataList = mutableListOf<FavData>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ListViewHolder(parent.inflate(R.layout.row_fav))
    }

    override fun getItemCount(): Int {
        return mDataList.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {

        holder.itemView.ivDelete.setOnClickListener {
            //set title for alert dialog
            val builder = AlertDialog.Builder(context.requireContext())
            builder.setTitle(R.string.dialogTitle)
            //set message for alert dialog
            builder.setMessage(R.string.dialogMessage)

            //performing positive action
            builder.setPositiveButton("Yes") { dialogInterface, which ->
                (context as onDeleteFavroite).onDeleteClick(i)
            }

            //performing negative action
            builder.setNegativeButton("No") { dialogInterface, which ->

            }
            // Create the AlertDialog
            val alertDialog: AlertDialog = builder.create()
            // Set other dialog properties
            alertDialog.setCancelable(false)
            alertDialog.show()
        }
        holder.itemView.tvStop.text = "#" + mDataList[i].stopID
        holder.itemView.tvName.text = mDataList[i].stopName
        if (mDataList[i].type == "bus") {
            holder.itemView.ivRail.setImageResource(R.drawable.bus)

            holder.itemView.tvStop.setTextColor(Color.parseColor("#CBFDD835"))

            holder.itemView.setOnClickListener {
                val intent = Intent(context.requireContext(), BusPredictionActivity::class.java)
                intent.putExtra("StopId", mDataList[i].stopID)
                intent.putExtra("StopName", mDataList[i].stopName)
                context.startActivity(intent)
            }
        } else {
            holder.itemView.setOnClickListener {
                val intent = Intent(context.requireContext(), RailPredictionActivity::class.java)
                intent.putExtra("stopID", mDataList[i].stopID)
                intent.putExtra("stopName", mDataList[i].stopName)
                intent.putExtra("lineColor", mDataList[i].lineColor)
                context!!.startActivity(intent)
            }
            holder.itemView.tvStop.setTextColor(Color.parseColor("#CBFDD835"))
        }
    }

    fun updateData(data: List<FavData>) {
        mDataList.clear()
        mDataList.addAll(data)
        notifyDataSetChanged()
    }


    private inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    interface onDeleteFavroite {
        fun onDeleteClick(position: Int)
    }
}