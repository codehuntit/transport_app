package com.app.transport.repository.models

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import com.app.transport.views.fragments.ImageFragment

@Parcelize
data class ImagePreview(
    val image: String = "",
    val caption: String = "",
    val imageType: Int = ImageFragment.IMAGE_TYPE_USER_PROFILE
) : Parcelable