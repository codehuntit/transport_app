package com.app.transport.utils

import android.app.Application
import com.app.transport.repository.preferences.UserPrefsManager
import com.facebook.drawee.backends.pipeline.Fresco
import java.util.*


class ApplicationGlobal : Application() {

    companion object {
        var accessToken: String = ""
        var refreshToken: String = ""
        var deviceLocale: String = ""
        var inChatConversationId: String? = null
        var timeZone = ""
    }

    override fun onCreate() {
        super.onCreate()
        // Initialize fresco
        Fresco.initialize(this)

        // Get device locale
        deviceLocale = Locale.getDefault().language

        // Get session id
        accessToken = UserPrefsManager(this).accessToken
//        refreshToken = HelperPreferences.get(this)._refresh_token

        // get timezone
        timeZone = TimeZone.getDefault().id
    }
    fun onSaveInPrefrence(accessToken: String, refreshToken: String)

    {
        HelperPreferences.get(this)
            .save_access_token(accessToken)
        HelperPreferences.get(this)
            .save_refresh_token(refreshToken)
    }
}
