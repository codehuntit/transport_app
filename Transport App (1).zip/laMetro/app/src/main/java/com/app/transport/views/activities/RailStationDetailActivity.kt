package com.app.transport.views.activities

import android.view.View
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.app.transport.R
import com.app.transport.base.BaseActivity
import com.app.transport.databinding.ActivityRailDetailBinding
import com.app.transport.repository.models.rail.RailRoute
import com.app.transport.repository.models.rail.RailStop
import com.app.transport.viewmodels.BaseViewModel
import com.app.transport.viewmodels.RailViewModel
import com.app.transport.views.adapters.RailDetailAdapter
import kotlinx.android.synthetic.main.toolbar.*


class RailStationDetailActivity : BaseActivity(), View.OnClickListener {
    var binding: ActivityRailDetailBinding? = null
    private val mRailListAdapter: RailDetailAdapter by lazy { RailDetailAdapter(this) }
    private val mRailViewModel by lazy { ViewModelProvider(this)[RailViewModel::class.java] }
var routeRailData = RailRoute()
    override fun getContentId(): Int {
        return R.layout.activity_rail_detail
    }

    override val viewModel: BaseViewModel?
        get() = mRailViewModel

    override fun init() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_rail_detail)
        toolbar.visibility = View.VISIBLE

        ivToolbarRightIcon.visibility = View.GONE
        searchView.visibility = View.GONE
        ivToolbarLeftIcon.visibility = View.VISIBLE
        tvToolbarTitle.text = "Metro Rail"
        ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon1)

        // set click listener
        ivToolbarRightIcon.setOnClickListener(this)
        ivToolbarLeftIcon.setOnClickListener(this)


        binding!!.progress.visibility=View.GONE
        mRailListAdapter.updateData( intent.getParcelableArrayListExtra<RailStop>("StopList")!!,intent.getStringExtra("lineColor")!!)
        // set adapter
        binding!!.rvBusDetail.adapter = mRailListAdapter


    }

    override fun observeProperties() {


    }

    override fun onClick(v: View?) {
        when (v?.id) {

            R.id.ivToolbarLeftIcon -> {

                finish()


            }  R.id.ivToolbarLeftIcon -> {

            ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon2)

            }
        }


    }
}