package com.app.transport.repository.models

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

data class PojoUserLogin(
    val data: UserData,
    val message: String,
    val statusCode: Int
)

data class UserData(
    val accessToken: String,
    val user: User?
)

@Parcelize
data class User(
    val __v: Int,
    val _id: String,
    val address: String,
    val countryCode: String,
    val createdAt: Long,
    val deviceToken: String,
    val dob: String,
    val firstName: String,
    val fullNumber: String,
    val gender: String,
    val interestedInGender: String,
    val isBlocked: Boolean,
    val isDeleted: Boolean,
    val isNotificationEnabled: Boolean,
    val lastName: String,
    val latitude: Double,
    val loginTime: Int,
    val longitude: Double,
    val meaningOfName: String,
    val phoneNumber: String,
    val ethnicity: String = "",
    val height: Double = 0.0,
    val photos: List<Photo>?,
    val storyBehindName: String,
    val userQuestions: List<UserQuestion>
) : Parcelable

@Parcelize
data class Photo(
    val _id: String = "",
    var caption: String = "",
    var image: String = ""
) : Parcelable

@Parcelize
data class UserQuestion(
    val _id: String = "",
    var answer: String = "",
    var briefText: String = "",
    val inputTextHint: String = "",
    val mediaTitle: String = "",
    var media: List<Media> = listOf(),
    val question: String = "",
    val questionType: Int = 1
) : Parcelable

@Parcelize
data class Media(
    val _id: String = "",
    val caption: String = "",
    var media: String = "",
    val type: Int = 1
) : Parcelable