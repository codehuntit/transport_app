package com.app.transport.views.adapters

import android.app.Activity
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.transport.R
import com.app.transport.base.inflate
import com.app.transport.repository.models.NearBy
import com.app.transport.repository.models.bus.StopX
import com.app.transport.views.activities.BusPredictionActivity
import kotlinx.android.synthetic.main.row_bus_stations.view.*
import kotlinx.android.synthetic.main.row_fav.view.tvName
import java.util.ArrayList

class NearByStationAdapter(var context: Activity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var mStopList = ArrayList<NearBy>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ListViewHolder(parent.inflate(R.layout.row_near_stations))
    }

    override fun getItemCount(): Int {
        return mStopList.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {
        holder.itemView.setOnClickListener {
            val intent = Intent(context, BusPredictionActivity::class.java)
            intent.putExtra("StopId",mStopList[i].code)
            intent.putExtra("StopName",mStopList[i].name)
            context.startActivity(intent)
        }
        holder.itemView.tvName.text = mStopList[i].name
        holder.itemView.tvStationNo.text = "#" + mStopList[i].code

    }

    fun updateData(mStopLists: List<NearBy>) {
        mStopList.clear()
        mStopList.addAll(mStopLists)
        notifyDataSetChanged()
    }


    private inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
}