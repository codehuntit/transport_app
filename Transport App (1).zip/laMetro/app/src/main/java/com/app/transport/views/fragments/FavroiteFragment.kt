package com.app.transport.views.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.app.transport.R
import com.app.transport.repository.models.favroites.FavData
import com.app.transport.repository.models.favroites.PojoFavroites
import com.app.transport.repository.preferences.UserPrefsManager
import com.app.transport.views.adapters.FavroiteAdapter
import kotlinx.android.synthetic.main.fragment_favroite.*
import kotlinx.android.synthetic.main.toolbar.*


class FavroiteFragment : Fragment(), View.OnClickListener, FavroiteAdapter.onDeleteFavroite {
    private val mFavroiteAdapter: FavroiteAdapter by lazy { FavroiteAdapter(this) }
    protected val mUserPrefsManager: UserPrefsManager by lazy { UserPrefsManager(requireContext().applicationContext) }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_favroite, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        progress.visibility = View.GONE
        // set toolbar
        tvToolbarTitle.text = "Favorites"
        ivToolbarRightIcon.setOnClickListener(this)
        ivToolbarLeftIcon.setOnClickListener(this)
        // set adapter
        rvFav.adapter = mFavroiteAdapter
        if (mUserPrefsManager.getFavData() != null
        ) {
            var FavroiteList = mUserPrefsManager.getFavData()

        if(FavroiteList.data!=null  && FavroiteList.data.isNotEmpty())
        {
            tvNoData.visibility=View.GONE
            progress.visibility=View.GONE
        mFavroiteAdapter.updateData(mUserPrefsManager.getFavData().data)}

            else
        {tvNoData.visibility=View.VISIBLE
            progress.visibility=View.GONE

        }


        }
    }

    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.ivToolbarRightIcon -> {
                ivToolbarRightIcon.visibility = View.GONE
                tvToolbarTitle.visibility = View.GONE
                searchView.visibility = View.VISIBLE
                ivToolbarLeftIcon.visibility = View.VISIBLE
            }
            R.id.ivToolbarLeftIcon -> {
                ivToolbarRightIcon.visibility = View.VISIBLE
                tvToolbarTitle.visibility = View.VISIBLE
                searchView.visibility = View.GONE
                ivToolbarLeftIcon.visibility = View.GONE
            }
        }
    }

    override fun onDeleteClick(position: Int) {
        var dataList = mutableListOf<FavData>()
        dataList.addAll(mUserPrefsManager.getFavData().data)
        dataList.removeAt(position)
        var PojoFavroites = PojoFavroites(dataList)

mUserPrefsManager.saveFavroiteData(PojoFavroites)
        mFavroiteAdapter.updateData(dataList)


        if(dataList.isNotEmpty()) {
            tvNoData.visibility = View.GONE
        }
        else
        {tvNoData.visibility=View.VISIBLE

        }
    }

}