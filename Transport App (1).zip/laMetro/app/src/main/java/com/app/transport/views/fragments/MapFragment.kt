package com.app.transport.views.fragments

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.app.transport.R
import com.facebook.drawee.backends.pipeline.Fresco
import kotlinx.android.synthetic.main.fragment_image.*
import kotlinx.android.synthetic.main.fragment_map.*
import kotlinx.android.synthetic.main.fragment_map.tvBus
import kotlinx.android.synthetic.main.fragment_map.tvTrain
import kotlinx.android.synthetic.main.fragment_map.zdvImage


class MapFragment : Fragment(), View.OnClickListener {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_map, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // set click listener

        tvTrain.setOnClickListener(this)
        tvBus.setOnClickListener(this)
        tvSystem.setOnClickListener(this)

    }

    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.tvBus -> {
                viewBus.setBackgroundColor(Color.parseColor("#ffffff"))
                viewTrain.setBackgroundColor(Color.parseColor("#2175A4"))
                viewSystem.setBackgroundColor(Color.parseColor("#2175A4"))
            }
            R.id.tvTrain -> {
                viewBus.setBackgroundColor(Color.parseColor("#2175A4"))
                viewTrain.setBackgroundColor(Color.parseColor("#ffffff"))
                viewSystem.setBackgroundColor(Color.parseColor("#2175A4"))



            }   R.id.tvSystem -> {
                viewBus.setBackgroundColor(Color.parseColor("#2175A4"))
                viewTrain.setBackgroundColor(Color.parseColor("#2175A4"))
            viewSystem.setBackgroundColor(Color.parseColor("#ffffff"))



            }
        }
    }

}