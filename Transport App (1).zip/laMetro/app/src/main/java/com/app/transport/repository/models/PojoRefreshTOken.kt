package com.app.transport.repository.models

data class PojoRefreshTOken(
    val access_token: String="",
    val expires_in: Int=0,
    val refresh_token: String="",
    val token_type: String=""
)