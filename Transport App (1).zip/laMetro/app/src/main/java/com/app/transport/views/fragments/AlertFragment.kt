package com.app.transport.views.fragments

import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.app.transport.R
import com.app.transport.repository.models.AlertData
import com.app.transport.viewmodels.AlertViewModel
import com.app.transport.viewmodels.BusViewModel
import com.app.transport.views.adapters.AlertAdapter
import com.app.transport.views.adapters.FavroiteAdapter
import kotlinx.android.synthetic.main.fragment_alert.*
import kotlinx.android.synthetic.main.toolbar.*


class AlertFragment : Fragment(), View.OnClickListener {
    private val mAlertAdapter: AlertAdapter by lazy { AlertAdapter(this) }
    private val mAlertViewModel by lazy { ViewModelProvider(this)[AlertViewModel::class.java] }
var mTrainAlertDataList = mutableListOf<AlertData>()
var mBusAlertDataList = mutableListOf<AlertData>()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_alert, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // set toolbar
        tvToolbarTitle.text = "Transit Alert/News"

        ivToolbarRightIcon.visibility = View.GONE
        searchView.visibility = View.GONE
        tvTrain.setOnClickListener(this)
        tvBus.setOnClickListener(this)
        // set adapter
        rvFav.adapter = mAlertAdapter

        mAlertViewModel.onGetAlertSuccess().observe(this, Observer {
            progress.visibility=View.GONE
            if(it.isNotEmpty())
            {

                for(i in it.indices)
                {
                    if(it[i].affected_services.services[0].mode_name=="Bus")
                    {

                        mBusAlertDataList.add(it[i])
                    }else
                    {
                        mTrainAlertDataList.add(it[i])

                    }


                }

                mAlertAdapter.updateData(mTrainAlertDataList)
                if(mTrainAlertDataList.isEmpty())
                {

                    tvNoData.visibility=View.VISIBLE
                }else
                {
                    tvNoData.visibility=View.GONE
                }
            }
        })


        // get data
        mAlertViewModel.getAlert()
    }

    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.tvBus -> {

                if(mBusAlertDataList.isEmpty())
                {

                    tvNoData.visibility=View.VISIBLE
                }else
                {
                    tvNoData.visibility=View.GONE
                }

                mAlertAdapter.updateData(mBusAlertDataList)

                viewBus.setBackgroundColor(Color.parseColor("#ffffff"))
                viewTrain.setBackgroundColor(Color.parseColor("#2175A4"))
            }
            R.id.tvTrain -> {

                if(mTrainAlertDataList.isEmpty())
                {

                    tvNoData.visibility=View.VISIBLE
                }else
                {
                    tvNoData.visibility=View.GONE
                }
                mAlertAdapter.updateData(mTrainAlertDataList)
                viewBus.setBackgroundColor(Color.parseColor("#2175A4"))
                viewTrain.setBackgroundColor(Color.parseColor("#ffffff"))



            }
        }
    }

}