package com.app.transport.repository.models

data class PojoGeneral(val message: String = "")