package com.app.transport.views.adapters

import android.content.Context
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.app.transport.R
import com.example.mvvmnewdemo.WithApiExample.model.EmployeData
import com.app.transport.base.inflate
import com.app.transport.repository.models.AlertData
import kotlinx.android.synthetic.main.load_data_layout.view.*
import kotlinx.android.synthetic.main.row_alert.view.*
import kotlinx.android.synthetic.main.row_fav.view.*

class AlertAdapter(var context: Fragment) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
var mDataList = mutableListOf<AlertData>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ListViewHolder(parent.inflate(R.layout.row_alert))
    }

    override fun getItemCount(): Int {
        return mDataList.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {

holder.itemView.tvTitle.text=mDataList[i].cause
holder.itemView.tvDesc.text=mDataList[i].short_header_text
holder.itemView.tvNote.text="When: "+mDataList[i].timeframe_text
    }

    fun updateData(data: MutableList<AlertData>) {
        mDataList.clear()
        mDataList.addAll(data)
        notifyDataSetChanged()
    }


    private inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
}