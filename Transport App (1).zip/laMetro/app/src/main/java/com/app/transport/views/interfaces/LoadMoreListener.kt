package com.app.transport.views.interfaces

interface LoadMoreListener {

    fun onLoadMore()

}