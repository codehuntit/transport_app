package com.app.transport.repository.networkrequests

object WebConstants {

    const val ACTION_BASE_URL = "https://retro.umoiq.com/"
    const val ACTION_AUTH = "97d62f962a8561fd3938b92efb0ed7dd"
    const val ACTION_REFRESH_TOEKN_BASE_URL = "https://.com/api/oauth/token?v=2"
    const val ACTION_PRIVACY_POLICY = "https://www..com/live/1266f167-f3a9-4c20-864f-4ec60c6e976d"
    const val ACTION_TERMS_CONDITION = "https://www..com/live/1d28d6e5-c7fc-48c0-9527-5725d72890d9"
    const val ACTION_CLIENT_ID = ""
    const val ACTION_CLIENT_SECRET = ""
    const val API_RAIL_LIST = "https://api.goswift.ly/info/lametro-rail/routes?verbose=true"
    const val API_RAIL_DEATIL_LIST = "https://obawestapi.dcmetroapp.com/api/where/stops-for-route/55_802.json?key=ARTBUSDATA"
    const val API_ALERT = "https://alerts.metroservices.io/developer/api/v2/alerts?api_key=4oJedLBt80WP-d7E6Ekf5w&format=json"



    //    const val ACTION_BASE_URL_FOR_APIS = "$ACTION_BASE_URL/api/v1/"
//    const val ACTION_CONTACT_US = "$ACTION_BASE_URL/contact-us"
//    const val ACTION_TERMS_AND_CONDITIONS = "$ACTION_BASE_URL/terms-and-conditions"
//    const val ACTION_PRIVACY_POLICY = "$ACTION_BASE_URL/privacy-policy"



}