package com.app.transport.views.adapters

import android.content.Intent
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.app.transport.R
import com.app.transport.base.inflate
import com.app.transport.repository.models.rail.RailRoute
import com.app.transport.views.activities.RailStationActivity
import com.app.transport.views.activities.RailStationDetailActivity
import kotlinx.android.synthetic.main.row_train.view.*
import java.util.*

class TrainAdapter(var context: Fragment) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var mTrainList = ArrayList<RailRoute>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ListViewHolder(parent.inflate(R.layout.row_train))
    }

    override fun getItemCount(): Int {
        return mTrainList.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {


        holder.itemView.rl.setBackgroundColor(Color.parseColor("#" + mTrainList[i].color))

        holder.itemView.tvName.text = mTrainList[i].longName



        holder.itemView.ivRail.text =  mTrainList[i].id

        holder.itemView.setOnClickListener {
            val intent = Intent(context.requireContext(), RailStationActivity::class.java)
            intent.putExtra("routeId", mTrainList[i].id)
            intent.putExtra("lineColor", mTrainList[i].color)
            intent.putExtra("routeRailData", mTrainList[i])
            context!!.startActivity(intent)
        }
    }

    fun updateData(it: List<RailRoute>?) {
        mTrainList.clear()
        mTrainList.addAll(it!!)
        notifyDataSetChanged()
    }


    private inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
}