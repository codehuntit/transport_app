package com.app.transport.repository.models.favroites

data class PojoFavroites (
    var data:List<FavData>

        )
data class FavData(
    var stopID:String,
    var type:String,
    var stopName:String,
    var lineColor:String

)
