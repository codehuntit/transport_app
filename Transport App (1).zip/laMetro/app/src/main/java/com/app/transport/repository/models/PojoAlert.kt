package com.app.transport.repository.models

data class PojoAlert(
    val alerts: List<AlertData>
)

data class AlertData(
    val affected_services: AffectedServices,
    val alert_id: Int,
    val alert_lifecycle: String,
    val cause: String,
    val cause_name: String,
    val created_dt: String,
    val description_text: String,
    val effect: String,
    val effect_name: String,
    val effect_periods: List<EffectPeriod>,
    val header_text: String,
    val last_modified_dt: String,
    val recurrence_text: String,
    val service_effect_text: String,
    val severity: String,
    val short_header_text: String,
    val timeframe_text: String,
    val url: String
)

data class AffectedServices(
    val elevators: List<Any>,
    val services: List<Service>
)

data class EffectPeriod(
    val effect_end: String,
    val effect_start: String
)

data class Service(
    val direction_id: String,
    val direction_name: String,
    val mode_name: String,
    val route_id: String,
    val route_name: String,
    val route_type: String,
    val stop_id: String,
    val stop_name: String
)