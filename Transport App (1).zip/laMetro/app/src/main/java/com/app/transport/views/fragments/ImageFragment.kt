package com.app.transport.views.fragments

import android.net.Uri
import android.os.Bundle
import android.view.View
import com.app.transport.R
import com.facebook.drawee.backends.pipeline.Fresco
import com.app.transport.base.BaseFragment
import com.app.transport.repository.models.ImagePreview
import com.app.transport.utils.GeneralFunctions
import com.app.transport.viewmodels.BaseViewModel
import kotlinx.android.synthetic.main.fragment_image.*
import java.io.File



class ImageFragment : BaseFragment() {

    companion object {

        internal const val IMAGE_TYPE_USER_PROFILE = 1
        internal const val IMAGE_TYPE_USER_QUESTIONS = 2

        const val BUNDLE_EXTRAS_IMAGE = "image"

        fun newInstance(image: ImagePreview): ImageFragment {
            val imageFragment = ImageFragment()
            val bundle = Bundle()
            bundle.putParcelable(BUNDLE_EXTRAS_IMAGE, image)
            imageFragment.arguments = bundle
            return imageFragment
        }
    }

    override val layoutId: Int
        get() = R.layout.fragment_image
    override val visibility: Boolean
        get() = true

    override fun init(savedInstanceState: Bundle?) {
        // Get image from arguments
        val imagePreview = arguments?.getParcelable(BUNDLE_EXTRAS_IMAGE) ?: ImagePreview()

        // check if image is a local file or url
        with(imagePreview) {
            if (GeneralFunctions.isRemoteImage(image)) {
                when (imageType) {

                }
            } else {
                val imageFile = File(image)
                if (imageFile.exists()) {
                    setImage(GeneralFunctions.getLocalImageFile(imageFile))
                }
            }

            if (caption.isNotEmpty()) {
                tvCaption.visibility = View.VISIBLE
                tvCaption.text = caption
            }
        }
    }

    private fun setImage(image: String) {
        zdvImage.setAllowTouchInterceptionWhileZoomed(true)
        val controller = Fresco.newDraweeControllerBuilder()
            .setUri(Uri.parse(image))
            .build()
        zdvImage.controller = controller
    }

    override val viewModel: BaseViewModel?
        get() = null

    override fun observeProperties() {
    }

}
