package com.app.transport.views.activities

import android.view.View
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.app.transport.R
import com.app.transport.base.BaseActivity
import com.app.transport.databinding.ActivityBusDetailBinding
import com.app.transport.repository.models.bus.Route
import com.app.transport.viewmodels.BaseViewModel
import com.app.transport.viewmodels.BusViewModel
import com.app.transport.views.adapters.BusRouteAdapter
import kotlinx.android.synthetic.main.toolbar.*


class BusRoutesActivity : BaseActivity(), View.OnClickListener {
    var binding: ActivityBusDetailBinding? = null
    private val mBusDetailAdapter: BusRouteAdapter by lazy { BusRouteAdapter(this) }
    private val mBusViewModel by lazy { ViewModelProvider(this)[BusViewModel::class.java] }

    override fun getContentId(): Int {
        return R.layout.activity_bus_detail
    }

    override val viewModel: BaseViewModel?
        get() = mBusViewModel

    override fun init() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_bus_detail)

        ivToolbarRightIcon.visibility = View.GONE
        toolbar.visibility = View.VISIBLE
        searchView.visibility = View.GONE
        ivToolbarLeftIcon.visibility = View.VISIBLE
        ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon1)
        tvToolbarTitle.text =intent.getStringExtra("routeName")!!
        // set click listener
        ivToolbarLeftIcon.setOnClickListener(this)
        ivToolbarRightIcon.setOnClickListener(this)

       // mBusViewModel.getRouteDetailByIDList(intent.getStringExtra("routeID")!!)


        var mRoute = intent.getParcelableExtra<Route>("routeData")
        mBusDetailAdapter.updateData(mRoute!!.directions,intent.getStringExtra("routeID")!!)
        binding!!.progress.visibility=View.GONE

        // set adapter
        binding!!.rvBusDetail.adapter = mBusDetailAdapter
    }

    override fun observeProperties() {

            mBusViewModel.onGetRouteDetailList().observe(this, Observer {

                if(it!=null )
                {

                }
            })

    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.ivToolbarRightIcon -> {

                ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon2)


            }
            R.id.ivToolbarLeftIcon -> {

                finish()


            }
        }


    }
}