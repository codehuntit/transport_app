package com.devstory.base.views.fragments

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.ViewGroup
import com.devstory.base.utils.MarshMallowPermissions
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.app.transport.R
import com.app.transport.base.BaseFragment
import com.app.transport.base.inflate
import com.app.transport.utils.GetSampledImage
import kotlinx.android.synthetic.main.show_picture_options_bottom_sheet.view.*
import java.io.File

/**
 * Created by Mukesh on 17/5/18.
 */
abstract class BasePictureOptionsFragment : BaseFragment(), GetSampledImage.SampledImageAsyncResp {

    companion object {
        private const val REQUEST_CODE_GALLERY_PHOTOS = 192
        private const val REQUEST_CODE_TAKE_PHOTO = 281
        const val INTENT_EXTRAS_IMAGE = "Camera_Image"
        const val BUNDLE_TAKE_ID = "FROM"
        const val BUNDLE_EXTRA_OPEN_CAMERA = 13456
    }

    private var picturePath: String? = null
    private var imagesDirectory: String? = null
    private var isCameraOptionSelected: Boolean = false
    private val mMarshMallowPermissions by lazy { MarshMallowPermissions(this) }
    private var imagesList = arrayListOf<String>()

    override fun init(savedInstanceState: Bundle?) {
        setData(savedInstanceState)
    }

    fun showPictureOptionsBottomSheet(
        imagesDirectory: String,
        showRecentUploadsOption: Boolean = false
    ) {
        val bottomSheetDialog = BottomSheetDialog(requireActivity())
        val view = (view as ViewGroup).inflate(R.layout.show_picture_options_bottom_sheet)

        view.tvCamera.setOnClickListener {
            checkForPermissions(true, imagesDirectory)
            bottomSheetDialog.dismiss()
        }
        view.tvGallery.setOnClickListener {
            checkForPermissions(false, imagesDirectory)
            bottomSheetDialog.dismiss()
        }

        view.tvCancel.setOnClickListener { bottomSheetDialog.dismiss() }

        bottomSheetDialog.setContentView(view)
        bottomSheetDialog.show()
    }

    private fun checkForPermissions(isCameraOptionSelected: Boolean, imagesDirectory: String) {
        this.isCameraOptionSelected = isCameraOptionSelected
        this.imagesDirectory = imagesDirectory

        if (mMarshMallowPermissions.isPermissionGrantedForWriteExtStorage) {
            if (isCameraOptionSelected) {
                startCameraIntent()
            } else {
                openGallery()
            }
        } else {
            mMarshMallowPermissions.requestPermissionForWriteExtStorage()
        }
    }

    private fun openGallery() {
        startActivityForResult(
            Intent(
                Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            ), REQUEST_CODE_GALLERY_PHOTOS
        )
    }

    private fun startCameraIntent() {
        /*    val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            try {
                val file = GeneralFunctions.setUpImageFile(imagesDirectory!!)
                picturePath = file!!.absolutePath

                val outputUri = FileProvider
                    .getUriForFile(requireActivity(), BuildConfig.APPLICATION_ID + ".provider", file)
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputUri)
                takePictureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)

            } catch (e: Exception) {
                e.printStackTrace()
                picturePath = null
            }
            startActivityForResult(takePictureIntent, REQUEST_CODE_TAKE_PHOTO)*/
        if (mMarshMallowPermissions.isCameraPermission) {
            onStartCameraDialogFragment(true)

        }else
        {
            mMarshMallowPermissions.giveCameraPermission()
        }

    }


    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            MarshMallowPermissions.RQ_WRITE_EXTERNAL_STORAGE ->
                if (PackageManager.PERMISSION_GRANTED == grantResults[0]) {
                    if (isCameraOptionSelected) {
                        startCameraIntent()
                    } else {
                        openGallery()
                    }
                } else {
                    showMessage(
                        R.string.enable_storage_permission, null,
                        false
                    )
                }
            MarshMallowPermissions.RQ_CAMERA_CAPTURE_PERMISSION->
                if (PackageManager.PERMISSION_GRANTED == grantResults[0]) {
                    if (isCameraOptionSelected) {
                        startCameraIntent()
                    } else {
                        openGallery()
                    }
                } else {
                    showMessage(
                        R.string.enable_storage_permission, null,
                        false
                    )
                }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (Activity.RESULT_OK == resultCode) {
            when (requestCode) {
                REQUEST_CODE_GALLERY_PHOTOS, REQUEST_CODE_TAKE_PHOTO -> {
                    var isGalleryImage = false
                    if (requestCode == REQUEST_CODE_GALLERY_PHOTOS) {
                        val selectedImage = data!!.data
                        val filePathColumn = arrayOf(MediaStore.Images.Media.DATA)
                        val cursor = requireActivity().contentResolver.query(
                            selectedImage!!,
                            filePathColumn, null, null, null
                        )
                        cursor!!.moveToFirst()
                        val columnIndex = cursor.getColumnIndex(filePathColumn[0])
                        picturePath = cursor.getString(columnIndex)
                        cursor.close()
                        isGalleryImage = true
                    }

                    // Downsample image
                    GetSampledImage(this).execute(
                        picturePath, imagesDirectory,
                        isGalleryImage.toString(),
                        resources.getDimension(R.dimen.image_downsample_size).toInt().toString()
                    )
                }
            }
        }

    }

    override fun onSampledImageAsyncPostExecute(file: File) {
        onGettingImageFile(file)
    }


    abstract fun setData(savedInstanceState: Bundle?)

    abstract fun onGettingImageFile(file: File)
    abstract fun onStartCameraDialogFragment(isOpen: Boolean)

    /// to open camera


/*    val cameraDialogFragment = CameraDialogFragment()
    cameraDialogFragment.setTargetFragment(this, BUNDLE_EXTRA_OPEN_CAMERA)
    cameraDialogFragment.show(parentFragmentManager, getString(R.string.dialog))
}


// get response
override fun onActivityResult(requestCode: Int, resultCode: Int, intent: Intent?) {
    super.onActivityResult(requestCode, resultCode, intent)
    if (Activity.RESULT_OK == resultCode && BasePictureOptionsFragment.BUNDLE_EXTRA_OPEN_CAMERA == requestCode) {
        // Get data from decline dialog
        Log.e("TAG", "onActivityResult: "+  intent?.getStringExtra(BasePictureOptionsFragment.INTENT_EXTRAS_IMAGE))

    }*/
}