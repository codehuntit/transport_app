package com.app.transport.repository.preferences

import android.content.Context
import android.content.SharedPreferences
import com.app.transport.repository.models.User
import com.app.transport.repository.models.UserData
import com.app.transport.repository.models.favroites.PojoFavroites
import com.app.transport.utils.ApplicationGlobal
import com.google.gson.Gson


class UserPrefsManager(context: Context) {

    private val mSharedPreferences: SharedPreferences
    private val mEditor: SharedPreferences.Editor

    companion object {
        // SharedPreference Keys
        private const val PREFS_FILENAME = "Appname"
        private const val PREFS_MODE = 0
        private const val PREFS_USER = "user"
        private const val PREFS_IS_LOGINED = "isLogined"
        private const val PREFS_ACCESS_TOKEN = "accessToken"
    }

    init {
        mSharedPreferences = context.getSharedPreferences(PREFS_FILENAME, PREFS_MODE)
        mEditor = mSharedPreferences.edit()
    }


    fun clearUserPrefs() {
        ApplicationGlobal.accessToken = ""
        mEditor.clear()
        mEditor.apply()
    }

    val isLogined: Boolean
        get() = mSharedPreferences.getBoolean(PREFS_IS_LOGINED, false)

    fun saveUserSession(isRememberMe: Boolean = true, userData: UserData) {
        if (isRememberMe) {
            mEditor.putBoolean(PREFS_IS_LOGINED, isRememberMe)
        }
        mEditor.putString(PREFS_ACCESS_TOKEN, userData.accessToken)
        ApplicationGlobal.accessToken = userData.accessToken

        userData.user?.let { user ->
            mEditor.putString(PREFS_USER, Gson().toJson(user))
        }
        mEditor.apply()
    }
    fun saveFavroiteData(pojoFavroites: PojoFavroites)
    {
        val gson = Gson()
        val json = gson.toJson(pojoFavroites)

        mEditor.putString("FavroteList", json)
        mEditor.commit()




    }


    fun getFavData(): PojoFavroites {
        val gson = Gson()
        val json: String = mSharedPreferences.getString("FavroteList", "{}")!!
        val obj = gson.fromJson(json, PojoFavroites::class.java)

        return  obj
    }
    val loginedUser: User?
        get() = Gson().fromJson(
            mSharedPreferences.getString(PREFS_USER, ""),
            User::class.java
        )

    fun updateUserData(user: User?) {
        if (null != user) {
            mEditor.putString(PREFS_USER, Gson().toJson(user))
            mEditor.apply()
        }
    }

    val accessToken: String
        get() = mSharedPreferences.getString(PREFS_ACCESS_TOKEN, "") ?: ""

}