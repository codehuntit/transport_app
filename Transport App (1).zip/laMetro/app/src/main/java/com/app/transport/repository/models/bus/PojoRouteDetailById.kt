package com.app.transport.repository.models.bus

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

data class PojoRouteDetailById(
    val copyright: String,
    val route: Routes
)

data class Routes(
    val color: String,
    val direction: List<Direction>,
    val latMax: String,
    val latMin: String,
    val lonMax: String,
    val lonMin: String,
    val oppositeColor: String,
    val path: List<Path>,
    val stop: List<StopX>,
    val tag: String,
    val title: String
)

data class Direction(
    val name: String,
    val stop: List<Stop>,
    val tag: String,
    val title: String,
    val useForUI: String
)

data class Path(
    val point: List<Point>
)
@Parcelize
data class StopX(
    val lat: String="",
    val lon: String="",
    val stopId: String="",
    val tag: String="",
    val title: String=""
)
    :Parcelable

data class Stop(
    val tag: String
)

data class Point(
    val lat: String,
    val lon: String
)