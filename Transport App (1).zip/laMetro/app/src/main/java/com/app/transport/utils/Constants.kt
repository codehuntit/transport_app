package com.app.transport.utils

import android.os.Environment


object Constants {

    private const val APP_NAME = "Base Project"

    // Date Time Format Constants
    const val DATE_FORMAT_SERVER = "yyyy-MM-d"
    const val DATE_FORMAT_DISPLAY = "d MMM, yyyy"

    // Media Constants
    private val LOCAL_STORAGE_BASE_PATH_FOR_MEDIA = Environment
        .getExternalStorageDirectory().toString() + "/" + APP_NAME
    val LOCAL_STORAGE_BASE_PATH_FOR_USER_PHOTOS = "$LOCAL_STORAGE_BASE_PATH_FOR_MEDIA/Users/Photos/"
    val LOCAL_STORAGE_BASE_PATH_FOR_QUESTION_PHOTOS =
        "$LOCAL_STORAGE_BASE_PATH_FOR_MEDIA/Questions/Media"
    val LOCAL_STORAGE_BASE_PATH_FOR_CHAT_MEDIA = "$LOCAL_STORAGE_BASE_PATH_FOR_MEDIA/Chats/"
    const val IMAGES_FOLDER = "Images/"
    const val VIDEOS_FOLDER = "Videos/"
    const val VIDEOS_THUMBS_FOLDER = "Thumbs/"
    object Keys {
        const val DEVICE_TOKEN = "app.device.token"
        const val USER_ID = "app.user.id"
        const val USER_TOKEN = "app.user.token."
        const val USER_CHAT = "app.user.chat."
        const val USER_NAME = "app.user.profile.name"
        const val USER_PIC = "app.user.profile.pic"
        const val USER_EMAIL = "app.user.profile.email"
        const val Save_Session_id = "app.user.Save_Session_id"
        const val CREATED_DATE = "app.token.created.date"
        const val PARAM_LANGUAGE = "app.selected.language"
        const val IS_LOGIN = "app.is_login"
        const val KEY_IMAGE = "KEY_IMAGE"
        const val access_token = "access_token"
        const val refresh_token = "refresh_token"
        const val Sinature = "Sinature"
        const val deviceId = "deviceId"
        const val onapalied_job = "onapalied_job"
        const val UId = "UId"
        const val service_staff_id = "service_staff_id"
    }

}