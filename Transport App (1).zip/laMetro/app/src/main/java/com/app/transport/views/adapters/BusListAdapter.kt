package com.app.transport.views.adapters

import android.content.Intent
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.app.transport.R
import com.app.transport.base.inflate
import com.app.transport.repository.models.bus.Route
import com.app.transport.views.activities.BusRoutesActivity
import kotlinx.android.synthetic.main.row_bus.view.*
import kotlinx.android.synthetic.main.row_fav.view.tvName


class BusListAdapter(var context: Fragment) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    val mDataList = mutableListOf<Route>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ListViewHolder(parent.inflate(R.layout.row_bus))
    }

    override fun getItemCount(): Int {
        return mDataList.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {
        var name = mDataList[i].directions[0].title.replace("To ", "") + " -" +
                mDataList[i].directions[1].title.replace("To ", "")
        holder.itemView.setOnClickListener {
            val intent = Intent(context.requireContext(), BusRoutesActivity::class.java)
            intent.putExtra("routeID", mDataList[i].shortName)
            intent.putExtra("routeName", name)
            intent.putExtra("routeData", mDataList[i])
            context!!.startActivity(intent)


        }

        holder.itemView.tvName.text = name
        holder.itemView.tvNo.text = mDataList[i].shortName

    }

    fun updateData(it: List<Route>?) {
        mDataList.clear()
        mDataList.addAll(it!!)
        notifyDataSetChanged()

    }


    private inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
}