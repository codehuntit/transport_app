package com.app.transport.viewmodels

import android.app.Application
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.app.transport.repository.interactors.BusIntrector
import com.app.transport.repository.interactors.GetEmploeyeIntrector
import com.app.transport.repository.models.NearBy
import com.app.transport.repository.models.PojoNearBy
import com.app.transport.repository.models.bus.*
import com.app.transport.repository.networkrequests.NetworkRequestCallbacks
import com.app.transport.repository.networkrequests.RetrofitRequest
import com.example.mvvmnewdemo.WithApiExample.model.EmployeData
import com.example.mvvmnewdemo.WithApiExample.model.EmployeRespnseModel
import retrofit2.Response
import java.lang.Exception

class BusViewModel(application: Application) : BaseViewModel(application) {
    private val mBusIntrector by lazy { BusIntrector() }
    private val mRouteList = MutableLiveData<List<Route>>()
    private val mRouteDetailList = MutableLiveData<Routes>()
    private val mPredictions = MutableLiveData<BusPredictionData>()
    private val mNearByStations = MutableLiveData<List<NearBy>>()

    fun getRouteList() {
        mCompositeDisposable.add(mBusIntrector.getBusData(object :
            NetworkRequestCallbacks {
            override fun onSuccess(response: Response<*>) {
                try {

                    val pojoNetworkResponse = RetrofitRequest.checkForResponseCode(response.code())
                    when {
                        pojoNetworkResponse.isSuccess && null != response.body() -> {

                            val pojoServiceRequest = response.body() as PojoBusRoutesList
                            mRouteList.value = pojoServiceRequest.data.routes
                        }

                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(t: Throwable) {

                RetrofitRequest.getRetrofitError(t)

            }
        }))
    }
    fun getRouteDetailByIDList(routeID:String) {
        var url ="https://retro.umoiq.com/service/publicJSONFeed?command=routeConfig&a=lametro&r="+routeID
        mCompositeDisposable.add(mBusIntrector.getBusRouteIDData(url,object :
            NetworkRequestCallbacks {
            override fun onSuccess(response: Response<*>) {
                try {

                    val pojoNetworkResponse = RetrofitRequest.checkForResponseCode(response.code())
                    when {
                        pojoNetworkResponse.isSuccess && null != response.body() -> {

                            val pojoServiceRequest = response.body() as PojoRouteDetailById
                            mRouteDetailList.value = pojoServiceRequest.route
                        }

                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(t: Throwable) {

                RetrofitRequest.getRetrofitError(t)

            }
        }))
    }
    fun getBusPredection(stopId:String) {

        var url = "https://api.goswift.ly/real-time/lametro/predictions?stop="+stopId
        mCompositeDisposable.add(mBusIntrector.getBusPredection(url,object :
            NetworkRequestCallbacks {
            override fun onSuccess(response: Response<*>) {
                try {

                    val pojoNetworkResponse = RetrofitRequest.checkForResponseCode(response.code())
                    when {
                        pojoNetworkResponse.isSuccess && null != response.body() -> {

                            val pojoServiceRequest = response.body() as PojoBusProdection
                            mPredictions.value = pojoServiceRequest.data
                        }

                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(t: Throwable) {

                RetrofitRequest.getRetrofitError(t)

            }
        }))
    }
    fun nearByStations(lat :String, long:String) {

        var url ="https://obawestapi.dcmetroapp.com/api/where/stops-for-location.json?key=ARTBUSDATA&Lat="+lat+"&Lon="+
                long+"&Radius=500"
        mCompositeDisposable.add(mBusIntrector.nearByStation(url,object :
            NetworkRequestCallbacks {
            override fun onSuccess(response: Response<*>) {
                try {

                    val pojoNetworkResponse = RetrofitRequest.checkForResponseCode(response.code())
                    when {
                        pojoNetworkResponse.isSuccess && null != response.body() -> {

                            val pojoServiceRequest = response.body() as PojoNearBy
                            mNearByStations.value = pojoServiceRequest.data.list
                        }

                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(t: Throwable) {

                RetrofitRequest.getRetrofitError(t)

            }
        }))
    }

    fun onGetRouteList() = mRouteList
    fun onGetRouteDetailList() = mRouteDetailList
    fun onGetBusPrediction() = mPredictions
    fun onGetNearBy() = mNearByStations


}