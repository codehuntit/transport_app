package com.app.transport.views.activities

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.FragmentTransaction
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.app.transport.R
import com.app.transport.views.fragments.AlertFragment
import com.app.transport.views.fragments.HomeFragment
import com.app.transport.views.fragments.NearBragment
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_dashboard2.*
import kotlinx.android.synthetic.main.app_bar_dashboard.*


class DashboardActivity : AppCompatActivity(),View.OnClickListener {
    var frameLayout: FrameLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard2)

        val toolbar: Toolbar = findViewById<View>(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)

        val drawer = findViewById<View>(R.id.drawer_layout) as DrawerLayout
        val toggle = ActionBarDrawerToggle(
            this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawer.setDrawerListener(toggle)
        toggle.syncState()
        ivToolbarRightIcon.setOnClickListener(this)
        ivToolbarLeftIcon.setOnClickListener(this)
        supportActionBar?.setDisplayShowTitleEnabled(false)
     /*   supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(true)
        supportActionBar!!.setDisplayUseLogoEnabled(true)*/
        frameLayout = findViewById(R.id.nav_host_fragment_content_dashboard)
        val fm = supportFragmentManager
        val fragmentTransaction: FragmentTransaction
        val fragment = HomeFragment()
        fragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.nav_host_fragment_content_dashboard, fragment)
            .addToBackStack(null)
        fragmentTransaction.commit()

        tvToolbarTitle.text = getString(R.string.fav)
        nav_view.setNavigationItemSelectedListener(NavigationView.OnNavigationItemSelectedListener { menuItem ->
            val id = menuItem.itemId
            //it's possible to do more actions on several items, if there is a large amount of items I prefer switch(){case} instead of if()
            when (id) {
                R.id.nav_home -> {
                    tvToolbarTitle.text = getString(R.string.fav)

                    val fm = supportFragmentManager
                    val fragment = HomeFragment()
                    val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                    fragmentTransaction.replace(R.id.nav_host_fragment_content_dashboard, fragment)
                        .addToBackStack(null)
                    fragmentTransaction.commit()
                }
                R.id.nav_near_by -> {
                    if (checkPermissions(this)) {
                        tvToolbarTitle.text = "Near By"
                        ivToolbarRightIcon.visibility = View.VISIBLE
                        tvToolbarTitle.visibility = View.VISIBLE
                        searchView.visibility = View.GONE
                        ivToolbarLeftIcon.visibility = View.GONE

                        val fm = supportFragmentManager


                        val fragment = NearBragment()
                        val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                        fragmentTransaction.replace(
                            R.id.nav_host_fragment_content_dashboard,
                            fragment
                        )
                            .addToBackStack(null)
                        fragmentTransaction.commit()
                    } else {
                        requestPermission(this, 12333)
                    }


                }
                R.id.setting -> {
                    tvToolbarTitle.text = "Setting"
                    ivToolbarRightIcon.visibility = View.VISIBLE
                    tvToolbarTitle.visibility = View.VISIBLE
                    searchView.visibility = View.GONE
                    ivToolbarLeftIcon.visibility = View.GONE
                    val fm = supportFragmentManager
                    val fragment = AlertFragment()
                    val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                    fragmentTransaction.replace(R.id.nav_host_fragment_content_dashboard, fragment)
                        .addToBackStack(null)
                    fragmentTransaction.commit()
                }
                R.id.nav_contact_us -> {
                    ivToolbarRightIcon.visibility = View.VISIBLE
                    tvToolbarTitle.visibility = View.VISIBLE
                    searchView.visibility = View.GONE
                    ivToolbarLeftIcon.visibility = View.GONE
                    val emailIntent = Intent(
                        Intent.ACTION_SENDTO, Uri.fromParts(
                            "mailto", "abc@gmail.com", null
                        )
                    )
                    emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject")
                    emailIntent.putExtra(Intent.EXTRA_TEXT, "Body")
                    startActivity(Intent.createChooser(emailIntent, "Send email..."))

                }

            }

            drawer.closeDrawer(GravityCompat.START)
            true
        })


        val lbm = LocalBroadcastManager.getInstance(this)
        lbm.registerReceiver(
            onProfileClickListener,
            IntentFilter("ToolbarName")
        )
    }
    /** Volume down button receiver used to trigger shutter */
    private val onProfileClickListener = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getStringExtra(
                    "title"
                )!="") {
                tvToolbarTitle.text =intent.getStringExtra(
                    "title"
                )
            }

        }
    }

    //  CHECK FOR LOCATION PERMISSION
    fun checkPermissions(activity: Activity?): Boolean {
        val result =
            ContextCompat.checkSelfPermission(activity!!, Manifest.permission.ACCESS_FINE_LOCATION)
        return if (result == PackageManager.PERMISSION_GRANTED) {
            true
        } else {
            false
        }
    }
    public fun  requestPermission(activity: Activity, code: Int){

        if (ActivityCompat.shouldShowRequestPermissionRationale(
                activity,
                Manifest.permission.ACCESS_FINE_LOCATION
            )){

            Toast.makeText(
                activity,
                "GPS permission allows us to access location data. Please allow in App Settings for additional functionality.",
                Toast.LENGTH_LONG
            ).show();

        } else {

            ActivityCompat.requestPermissions(
                activity,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), code
            );
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)


        when (requestCode) {
            12333 -> {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.size > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED
                ) {

                    tvToolbarTitle.text = "Near By"
                    ivToolbarRightIcon.visibility = View.VISIBLE
                    tvToolbarTitle.visibility = View.VISIBLE
                    searchView.visibility = View.GONE
                    ivToolbarLeftIcon.visibility = View.GONE

                    val fm = supportFragmentManager


                    val fragment = NearBragment()
                    val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                    fragmentTransaction.replace(
                        R.id.nav_host_fragment_content_dashboard,
                        fragment
                    )
                        .addToBackStack(null)
                    fragmentTransaction.commit()
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return
            }
        }
    }

    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.ivToolbarRightIcon -> {
                ivToolbarRightIcon.visibility = View.GONE
                tvToolbarTitle.visibility = View.GONE
                searchView.visibility = View.VISIBLE
                ivToolbarLeftIcon.visibility = View.VISIBLE
            }
            R.id.ivToolbarLeftIcon -> {
                ivToolbarRightIcon.visibility = View.VISIBLE
                tvToolbarTitle.visibility = View.VISIBLE
                searchView.visibility = View.GONE
                ivToolbarLeftIcon.visibility = View.GONE
            }
        }
    }


}