package com.app.transport.views.adapters

import android.app.Activity
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.app.transport.R
import com.app.transport.base.inflate
import com.app.transport.repository.models.bus.PredictionsData
import com.app.transport.repository.models.rail.Direction
import com.app.transport.repository.models.rail.PojoRailPrediction
import com.app.transport.repository.models.rail.Prediction
import com.app.transport.repository.models.rail.PredictionX
import kotlinx.android.synthetic.main.row_bus_detail.view.*
import kotlinx.android.synthetic.main.row_train_prediction.view.*
import kotlinx.android.synthetic.main.row_train_prediction.view.tvName
import kotlinx.android.synthetic.main.row_train_prediction.view.tvTime
import java.util.ArrayList

class RailListAdapter(var context: Activity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val mDataList = mutableListOf<com.app.transport.repository.models.bus.Prediction>()
    var mPrediction = PredictionsData()
    var name = ""
    var mLineColor = ""
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ListViewHolder(parent.inflate(R.layout.row_train_prediction))
    }

    override fun getItemCount(): Int {
        return mDataList.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {
        holder.itemView.view.setBackgroundColor(Color.parseColor("#" + mLineColor));


        holder.itemView.tvName.text = name+" arrives in "

        holder.itemView.tvTime.text = mDataList[i].min.toString() + " minutes"
        if(mDataList[i].min<5)
        {
            holder.itemView.tvTime.setTextColor(ContextCompat.getColor(context, R.color.colorRed));}
    }

    fun updateData(prediction: List<PredictionsData>, lineColor: String) {
        mDataList.clear()
        mLineColor = lineColor
        name = prediction[0].destinations[0].headsign
        mPrediction = prediction[0]
        mDataList.addAll(prediction[0].destinations[0].predictions)
        notifyDataSetChanged()
    }


    private inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
}