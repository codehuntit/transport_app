package com.app.transport.views.activities

import android.graphics.Color
import android.view.View
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.FragmentTransaction
import com.app.transport.R
import com.app.transport.base.BaseActivity
import com.app.transport.databinding.ActivityBusDetailBinding
import com.app.transport.databinding.ActivityMainBinding
import com.app.transport.repository.models.bus.StopX
import com.app.transport.repository.models.bus.Stops
import com.app.transport.viewmodels.BaseViewModel
import com.app.transport.views.adapters.BusDetailAdapter
import com.app.transport.views.adapters.BusListAdapter
import com.app.transport.views.adapters.BusRouteAdapter
import com.app.transport.views.adapters.BusStationsAdapter
import com.app.transport.views.fragments.*
import kotlinx.android.synthetic.main.toolbar.*


class BusStationDetailActivity : BaseActivity(), View.OnClickListener {
    var binding: ActivityBusDetailBinding? = null
    private val mBusDetailAdapter: BusStationsAdapter by lazy { BusStationsAdapter(this) }
    var mStopList = ArrayList<Stops>()

    override fun getContentId(): Int {
        return R.layout.activity_bus_station
    }

    override val viewModel: BaseViewModel?
        get() = null

    override fun init() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_bus_detail)

        ivToolbarRightIcon.visibility = View.GONE
        toolbar.visibility = View.VISIBLE
        searchView.visibility = View.GONE
        ivToolbarLeftIcon.visibility = View.VISIBLE
        ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon1)
        tvToolbarTitle.text = "Bus Stops"
        // set click listener
        ivToolbarLeftIcon.setOnClickListener(this)
        ivToolbarRightIcon.setOnClickListener(this)

        if(intent.getParcelableArrayListExtra<Stops>("StopList")!=null)
        {
            mStopList = intent.getParcelableArrayListExtra<Stops>("StopList")!!
            mBusDetailAdapter.updateData(mStopList)
            binding!!.progress.visibility=View.GONE
        }


        // set adapter
        binding!!.rvBusDetail.adapter = mBusDetailAdapter
    }

    override fun observeProperties() {
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.ivToolbarRightIcon -> {

                ivToolbarRightIcon.setImageResource(R.drawable.favorite_icon2)


            }
            R.id.ivToolbarLeftIcon -> {

                finish()


            }
        }


    }
}