package com.app.transport.views.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.app.transport.R
import com.app.transport.viewmodels.BusViewModel
import com.app.transport.viewmodels.RailViewModel
import com.app.transport.views.adapters.FavroiteAdapter
import com.app.transport.views.adapters.TrainAdapter
import kotlinx.android.synthetic.main.fragment_favroite.*
import kotlinx.android.synthetic.main.toolbar.*


class TrainFragment : Fragment(), View.OnClickListener {
    private val mTrainAdapter: TrainAdapter by lazy { TrainAdapter(this) }
    private val mRailViewModel by lazy { ViewModelProvider(this)[RailViewModel::class.java] }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_favroite, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // set toolbar
        tvToolbarTitle.text = "La Train Routes"
        ivToolbarRightIcon.setOnClickListener(this)
        ivToolbarLeftIcon.setOnClickListener(this)
        // set adapter
        rvFav.adapter = mTrainAdapter

        observer()

        // get metro list
        mRailViewModel.getRailList()
    }

    private fun observer() {
        mRailViewModel.onGetMetroRouteList().observe(this, Observer {

            if (it != null) {
                progress.visibility = View.GONE
                mTrainAdapter.updateData(it)
            }
        })

    }

    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.ivToolbarRightIcon -> {
                ivToolbarRightIcon.visibility = View.GONE
                tvToolbarTitle.visibility = View.GONE
                searchView.visibility = View.VISIBLE
                ivToolbarLeftIcon.visibility = View.VISIBLE
            }
            R.id.ivToolbarLeftIcon -> {
                ivToolbarRightIcon.visibility = View.VISIBLE
                tvToolbarTitle.visibility = View.VISIBLE
                searchView.visibility = View.GONE
                ivToolbarLeftIcon.visibility = View.GONE
            }
        }
    }

}