package com.app.transport.base

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer

import com.app.transport.R
import com.app.transport.utils.HelperPreferences
import com.app.transport.utils.MyCustomLoader
import com.app.transport.viewmodels.BaseViewModel
import com.app.transport.views.activities.MainActivity
import com.app.transport.views.dialgofragments.CustomProgressBar
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

/**
 * Created by Gurpreet  preetforapps on 09/06/2021.
 */

abstract class BaseActivity : AppCompatActivity() {
    lateinit var self: Context
    private val mMyCustomLoader: MyCustomLoader by lazy { MyCustomLoader(this) }


    lateinit var mTvHeader: TextView
    lateinit var mCustomProgress: CustomProgressBar;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_base)
        mCustomProgress = CustomProgressBar(this)
        if (getContentId() != 0) {
            setContentView(getContentId())
            //  initiate()
        }

        self = this@BaseActivity
        observeBaseProperties()
        init()
    }

/*
    private fun initiate() {
        mIncludeHeader = findViewById(R.id.include_header)
        mIvBack = mIncludeHeader.findViewById(R.id.iv_back)
        mTvHeader = mIncludeHeader.findViewById(R.id.tv_header)

        mIvBack.setOnClickListener { onLeftIconClick() }
    }
*/
  fun toolbarTranparent(isTrans:Boolean){
    if(isTrans)
    {
        window.statusBarColor = ContextCompat.getColor(this, R.color.colorTransparent)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }
    else
    {
        window.statusBarColor = ContextCompat.getColor(this, R.color.colorWhite)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

}
    private fun observeBaseProperties() {
        // Observe message
        viewModel?.getSuccessMessage()?.observe(this, Observer {
            showMessage(null, it)
        })

        // Observe any general exception
        viewModel?.getErrorHandler()?.observe(this, Observer {
            if (null != it) {
                showMessage(resId = it.getErrorResource(), isShowSnackbarMessage = false)
            }
        })

        // Observe user session expiration
        viewModel?.isSessionExpired()?.observe(this, Observer {
            if (it!!) {

            }
        })
        // Observe user session expiration
        viewModel?.isRefreshTokenExpired()?.observe(this, Observer {
            if (it!!) {
                navigateToMainActivity()
            }
        })


        // Observe visibility of loader
        viewModel?.isShowLoader()?.observe(this, Observer {
            if (it!!) {
                showProgressLoader()
            } else {
                hideProgressLoader()
            }
        })

        // Observe retrofit error messages
        viewModel?.getRetrofitErrorMessage()?.observe(this, Observer {
            showMessage(
                resId = it?.errorResId,
                message = it?.errorMessage,
                isShowSnackbarMessage = false
            )
        })

        // Observe screen specific data
        observeProperties()
    }

    override fun onStart() {
    super.onStart()
    EventBus.getDefault().register(this)
}

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

    protected fun navigateToMainActivity() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
finishAffinity()    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    open fun onMessageEvent(event: String?) {

        if(event=="logout")
        {
            Toast.makeText(this, getString(R.string.session_expired), Toast.LENGTH_SHORT).show()
            HelperPreferences.get(this).clear()
            val intent = Intent(applicationContext, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)}
    }
    fun showProgressDialog(){
        mCustomProgress.showHideProgressBar(true)
    }
    fun hideProgressDialog(){
        mCustomProgress.hideProgressBar()
    }

    fun showSuccessToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    fun showErrorToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    fun onLeftIconClick() {
        onBackPressed()
//        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    fun setHeader(title: String) {
        mTvHeader.text = title
    }

    protected fun showProgressLoader() {
        mMyCustomLoader.showProgressDialog()
    }

    protected fun hideProgressLoader() {
        mMyCustomLoader.dismissProgressDialog()
    }
    // show the common progress which is used in all application


    fun gotoActivity(intent: Intent) {
        intent.putExtra("classFrom", self.javaClass.getSimpleName())
        startActivity(intent)
        overridePendingTransition(R.animator.slide_right_in, R.animator.slide_right_out)
    }

    fun gotoActivityWithResult(cla: Class<*>, code: Int) {
        val intent = Intent(this, cla)
        intent.putExtra("classFrom", self.javaClass.getSimpleName())
        startActivityForResult(intent, code)
    }

    fun gotoActivityClearTask(cla: Class<*>) {
        val intent = Intent(this, cla)
        intent.putExtra("classFrom", self.javaClass.getSimpleName())
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    fun gotoActivity(cla: Class<*>, bundle: Bundle) {
        val intent = Intent(this, cla)
        intent.putExtras(bundle)
        startActivity(intent)
    }

    fun gotoActivityWithResult(cla: Class<*>, bundle: Bundle, code: Int) {
        val intent = Intent(this, cla)
        intent.putExtras(bundle)
        startActivityForResult(intent, code)
    }

    // hide keyboard
    protected fun hideKeyboard(view: View?) {
        if (view != null) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }


    fun showMessage(
        resId: Int? = null, message: String? = null,
        isShowSnackbarMessage: Boolean = false
    ) {
        if (isShowSnackbarMessage) {
        } else {
            mMyCustomLoader.showToast(message ?: getString(resId!!))
        }
    }
    protected abstract fun getContentId(): Int

    abstract val viewModel: BaseViewModel?
    abstract fun init()
    abstract fun observeProperties()

}
