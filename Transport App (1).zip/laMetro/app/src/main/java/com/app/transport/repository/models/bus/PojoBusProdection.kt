package com.app.transport.repository.models.bus

data class PojoBusProdection(
    val `data`: BusPredictionData,
    val route: String="",
    val success: Boolean
)

data class BusPredictionData(
    val agencyKey: String="",
    val predictionsData: List<PredictionsData> = mutableListOf()
)

data class PredictionsData(
    val destinations: List<Destination> = mutableListOf(),
    val routeId: String="",
    val routeName: String="",
    val routeShortName: String="",
    val stopCode: Int=0,
    val stopId: String="",
    val stopName: String=""
)

data class Destination(
    val directionId: String="",
    val headsign: String="",
    val predictions: List<Prediction> = mutableListOf()
)

data class Prediction(
    val departure: Boolean= false,
    val min: Int=0,
    val sec: Int=0,
    val time: Int=0,
    val tripId: String="",
    val vehicleId: String=""
)