package com.app.transport.viewmodels

import android.app.Application
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.app.transport.repository.interactors.BusIntrector
import com.app.transport.repository.interactors.GetEmploeyeIntrector
import com.app.transport.repository.interactors.RailIntrector
import com.app.transport.repository.models.bus.*
import com.app.transport.repository.models.rail.*
import com.app.transport.repository.networkrequests.NetworkRequestCallbacks
import com.app.transport.repository.networkrequests.RetrofitRequest
import com.app.transport.repository.networkrequests.WebConstants
import com.example.mvvmnewdemo.WithApiExample.model.EmployeData
import com.example.mvvmnewdemo.WithApiExample.model.EmployeRespnseModel
import kotlinx.android.synthetic.main.row_train.view.*
import retrofit2.Response
import java.lang.Exception

class RailViewModel(application: Application) : BaseViewModel(application) {
    private val mRailIntrector by lazy { RailIntrector() }
    private val mMetroList = MutableLiveData<List<RailRoute>>()
    private val mRailData = MutableLiveData<RailData>()

    private val mPredictionData = MutableLiveData<BusPredictionData>()


    fun getRailList() {

        mCompositeDisposable.add(mRailIntrector.getRailLine(WebConstants.API_RAIL_LIST,object :
            NetworkRequestCallbacks {
            override fun onSuccess(response: Response<*>) {
                try {

                    val pojoNetworkResponse = RetrofitRequest.checkForResponseCode(response.code())
                    when {
                        pojoNetworkResponse.isSuccess && null != response.body() -> {

                            val pojoServiceRequest = response.body() as PojoMetroLine
                            mMetroList.value = pojoServiceRequest.data.routes
                        }

                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(t: Throwable) {

                RetrofitRequest.getRetrofitError(t)

            }
        }))
    }
    fun getRailRouteDetail(route_id:String) {
var url ="https://obawestapi.dcmetroapp.com/api/where/stops-for-route/"+route_id+".json?key=ARTBUSDATA"
        mCompositeDisposable.add(mRailIntrector.getRailRouteDetail(url,object :
            NetworkRequestCallbacks {
            override fun onSuccess(response: Response<*>) {
                try {

                    val pojoNetworkResponse = RetrofitRequest.checkForResponseCode(response.code())
                    when {
                        pojoNetworkResponse.isSuccess && null != response.body() -> {

                            val pojoServiceRequest = response.body() as PojoTrainRouteDetail
                            mRailData.value = pojoServiceRequest.data
                        }

                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(t: Throwable) {

                RetrofitRequest.getRetrofitError(t)

            }
        }))
    }
    fun getRailPrediction(stopID:String) {


        var url = "https://api.goswift.ly/real-time/lametro-rail/predictions?stop="+stopID


        mCompositeDisposable.add(mRailIntrector.getRailPrediction(url,object :
            NetworkRequestCallbacks {
            override fun onSuccess(response: Response<*>) {
                try {

                    val pojoNetworkResponse = RetrofitRequest.checkForResponseCode(response.code())
                    when {
                        pojoNetworkResponse.isSuccess && null != response.body() -> {

                            val pojoServiceRequest = response.body() as PojoBusProdection
                            mPredictionData.value = pojoServiceRequest.data
                        }

                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(t: Throwable) {

                RetrofitRequest.getRetrofitError(t)

            }
        }))
    }

    fun onGetMetroRouteList() = mMetroList
    fun onGetMetroRouteDetail() = mRailData
    fun onGetPredictionData() = mPredictionData



}