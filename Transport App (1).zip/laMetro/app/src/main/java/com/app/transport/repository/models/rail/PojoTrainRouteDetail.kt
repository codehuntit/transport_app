package com.app.transport.repository.models.rail

data class PojoTrainRouteDetail(
    val code: Int,
    val currentTime: Long,
    val `data`: RailData,
    val text: String,
    val version: Int
)

data class RailData(
    val entry: Entry,
    val references: RailReferences
)

data class Entry(
    val polylines: List<Polyline>,
    val routeId: String,
    val stopGroupings: List<StopGrouping>,
    val stopIds: List<String>
)

data class RailReferences(
    val agencies: List<Agencys>,
    val routes: List<Route>,
    val situations: List<Any>,
    val stops: List<Stop>,
    val trips: List<Any>
)

data class Polyline(
    val length: Int,
    val levels: String,
    val points: String
)

data class StopGrouping(
    val ordered: Boolean,
    val stopGroups: List<StopGroup>,
    val type: String
)

data class StopGroup(
    val id: String,
    val name: Name,
    val polylines: List<PolylineX>,
    val stopIds: List<String>,
    val subGroups: List<Any>
)

data class Name(
    val name: String,
    val names: List<String>,
    val type: String
)

data class PolylineX(
    val length: Int,
    val levels: String,
    val points: String
)

data class Agencys(
    val disclaimer: String,
    val id: String,
    val lang: String,
    val name: String,
    val phone: String,
    val privateService: Boolean,
    val timezone: String,
    val url: String
)

data class Route(
    val agencyId: String,
    val color: String,
    val description: String,
    val id: String,
    val longName: String,
    val shortName: String,
    val textColor: String,
    val type: Int,
    val url: String
)

data class Stop(
    val code: String,
    val direction: String,
    val id: String,
    val lat: Double,
    val locationType: Int,
    val lon: Double,
    val name: String,
    val routeIds: List<String>,
    val wheelchairBoarding: String
)