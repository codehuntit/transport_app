package com.app.transport.repository.models


class SessionTokenResponseModel {
    var session: String? = null

}
