package com.app.transport.views.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.app.transport.R
import com.app.transport.utils.Gps
import com.app.transport.viewmodels.BusViewModel
import com.app.transport.views.adapters.NearByStationAdapter
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.android.synthetic.main.fragment_near_bragment.*


class NearBragment : Fragment() ,OnMapReadyCallback{
   private var mMap : GoogleMap? = null
    private val mBusViewModel by lazy { ViewModelProvider(this)[BusViewModel::class.java] }
    private val mNearByStationAdapter: NearByStationAdapter by lazy { NearByStationAdapter(
        requireActivity()
    ) }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_near_bragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // get near by

        rvNearBy.adapter = mNearByStationAdapter

        // get data
        observerData()


        // Initialize map fragment
        // Initialize map fragment
        (childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?)?.getMapAsync(this)

    }

    private  fun observerData()
    {
        mBusViewModel.onGetNearBy().observe(this, androidx.lifecycle.Observer {

            if (it != null && it.isNotEmpty()) {
                mNearByStationAdapter.updateData(it)
                mMap!!.clear()
                for (i in it.indices) {
                    val marker =
                        MarkerOptions().position(LatLng(it[i].lat, it[i].lon)).title(it[i].name)


                    mMap!!.addMarker(marker)
                }
            }
        })
    }

    private fun getLocation() {
        val gps = Gps(requireContext())

        mBusViewModel.nearByStations(gps.latitude.toString(), gps.longitude.toString())

        val center =
            CameraUpdateFactory.newLatLng(LatLng(gps.getLatitude(), gps.getLongitude()))
        val zoom = CameraUpdateFactory.zoomTo(15f)
        mMap!!.moveCamera(center)
        mMap!!.animateCamera(zoom)
    }

    override fun onMapReady(p0: GoogleMap?) {
        mMap = p0
        getLocation()
        mMap!!.isMyLocationEnabled = true
    }


}