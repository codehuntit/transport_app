package com.app.transport.repository.models

data class PojoNetworkResponse(val isSuccess: Boolean, val isSessionExpired: Boolean,val isRefreshToken:Boolean)