package com.app.transport.repository.models

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@Parcelize
data class Country(val name: String = "", val dial_code: String = "", val code: String = "") :
    Parcelable