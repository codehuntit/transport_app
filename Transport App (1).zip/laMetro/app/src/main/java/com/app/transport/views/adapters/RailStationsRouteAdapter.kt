package com.app.transport.views.adapters

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.transport.R
import com.app.transport.base.inflate
import com.app.transport.repository.models.bus.*
import com.app.transport.repository.models.rail.RailDirection
import com.app.transport.views.activities.BusStationDetailActivity
import com.app.transport.views.activities.RailStationDetailActivity
import kotlinx.android.synthetic.main.row_bus.view.*
import kotlinx.android.synthetic.main.row_fav.view.tvName
import kotlinx.android.synthetic.main.row_rail.view.*

class RailStationsRouteAdapter(var context: Activity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    val mDataList = mutableListOf<RailDirection>()
var lineColor=""
var routeID=""
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ListViewHolder(parent.inflate(R.layout.row_bus_route))
    }

    override fun getItemCount(): Int {
        return mDataList.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {
        holder.itemView.setOnClickListener {
            val intent = Intent(context, RailStationDetailActivity::class.java)
            intent.putExtra("lineColor",lineColor)
            intent.putParcelableArrayListExtra("StopList", mDataList[i].stops)
            context.startActivity(intent)
        }

        holder.itemView.tvNo.background.setTint(Color.parseColor("#$lineColor"));

        holder.itemView.tvName.text = mDataList[i].title
        holder.itemView.tvNo.text = routeID

    }

    fun updateData(it: List<RailDirection>, lColor: String,routeId:String) {
        routeID = routeId
        lineColor = lColor
        mDataList.clear()
        mDataList.addAll(it)
        notifyDataSetChanged()
    }


    private inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
}