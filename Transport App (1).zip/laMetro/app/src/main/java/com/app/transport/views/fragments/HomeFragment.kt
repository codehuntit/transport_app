package com.app.transport.views.fragments

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentTransaction
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.app.transport.R
import kotlinx.android.synthetic.main.fragment_home.*


class HomeFragment : Fragment() ,View.OnClickListener {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)


      liFav.setOnClickListener(this)
      liBus.setOnClickListener(this)
      liTrain.setOnClickListener(this)
      liMaps.setOnClickListener(this)
      liAlert.setOnClickListener(this)

        // load fragment
        val fm = childFragmentManager
        val fragment = FavroiteFragment()
        val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.flHome, fragment)
            .addToBackStack(null)
        fragmentTransaction.commit()
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.liFav -> {
                LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(
                    Intent("ToolbarName").putExtra("title", getString(R.string.fav))

                )
                val fm = childFragmentManager
                val fragment = FavroiteFragment()
                val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.flHome, fragment)
                    .addToBackStack(null)
                fragmentTransaction.commit()


              liFav.setBackgroundColor(Color.parseColor("#2175A4"))
              liBus.setBackgroundColor(Color.parseColor("#D2000000"))
              liTrain.setBackgroundColor(Color.parseColor("#D2000000"))
              liMaps.setBackgroundColor(Color.parseColor("#D2000000"))
              liAlert.setBackgroundColor(Color.parseColor("#D2000000"))
            }
            R.id.liBus -> {
                LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(
                    Intent("ToolbarName").putExtra("title", getString(R.string.bus))

                )
                val fm = childFragmentManager
                val fragment = BusFragment()
                val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.flHome, fragment)
                    .addToBackStack(null)
                fragmentTransaction.commit()
              liFav.setBackgroundColor(Color.parseColor("#D2000000"))
              liBus.setBackgroundColor(Color.parseColor("#2175A4"))
              liTrain.setBackgroundColor(Color.parseColor("#D2000000"))
              liMaps.setBackgroundColor(Color.parseColor("#D2000000"))
              liAlert.setBackgroundColor(Color.parseColor("#D2000000"))
            }
            R.id.liTrain -> {
                LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(
                    Intent("ToolbarName").putExtra("title", getString(R.string.train))

                )


                val fm = childFragmentManager
                val fragment = TrainFragment()
                val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.flHome, fragment)
                    .addToBackStack(null)
                fragmentTransaction.commit()
              liFav.setBackgroundColor(Color.parseColor("#D2000000"))
              liBus.setBackgroundColor(Color.parseColor("#D2000000"))
              liTrain.setBackgroundColor(Color.parseColor("#2175A4"))
              liMaps.setBackgroundColor(Color.parseColor("#D2000000"))
              liAlert.setBackgroundColor(Color.parseColor("#D2000000"))
            }
            R.id.liMaps -> {
                LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(
                    Intent("ToolbarName").putExtra("title", getString(R.string.maps))

                )
                val fm = childFragmentManager
                val fragment = MapFragment()
                val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.flHome, fragment)
                    .addToBackStack(null)
                fragmentTransaction.commit()
              liFav.setBackgroundColor(Color.parseColor("#D2000000"))
              liBus.setBackgroundColor(Color.parseColor("#D2000000"))
              liTrain.setBackgroundColor(Color.parseColor("#D2000000"))
              liMaps.setBackgroundColor(Color.parseColor("#2175A4"))
              liAlert.setBackgroundColor(Color.parseColor("#D2000000"))

            }
            R.id.liAlert -> {
                LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(
                    Intent("ToolbarName").putExtra("title", getString(R.string.alert))

                )
                val fm = childFragmentManager
                val fragment = AlertFragment()
                val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.flHome, fragment)
                    .addToBackStack(null)
                fragmentTransaction.commit()
              liFav.setBackgroundColor(Color.parseColor("#D2000000"))
              liBus.setBackgroundColor(Color.parseColor("#D2000000"))
              liTrain.setBackgroundColor(Color.parseColor("#D2000000"))
              liMaps.setBackgroundColor(Color.parseColor("#D2000000"))
              liAlert.setBackgroundColor(Color.parseColor("#2175A4"))
            }
        }
    }
}