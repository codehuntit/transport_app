package com.example.mvvmnewdemo.WithApiExample.model

class EmployeData {

    var id: String = ""
    var employee_name: String = ""

    var employee_salary: String = ""
    var employee_age: String = ""
    var profile_image: String = ""
}
