package com.app.transport.viewmodels

import android.app.Application
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.app.transport.repository.interactors.AlertIntrector
import com.app.transport.repository.interactors.GetEmploeyeIntrector
import com.app.transport.repository.models.AlertData
import com.app.transport.repository.models.PojoAlert
import com.app.transport.repository.networkrequests.NetworkRequestCallbacks
import com.app.transport.repository.networkrequests.RetrofitRequest
import com.example.mvvmnewdemo.WithApiExample.model.EmployeData
import com.example.mvvmnewdemo.WithApiExample.model.EmployeRespnseModel
import retrofit2.Response
import java.lang.Exception

class AlertViewModel(application: Application) : BaseViewModel(application) {
    private val mAlertIntrector by lazy { AlertIntrector() }
    private val isAlertData = MutableLiveData<List<AlertData>>()

    fun getAlert() {
        isShowSwipeRefreshLayout.value = true
        mCompositeDisposable.add(mAlertIntrector.alert(object :
            NetworkRequestCallbacks {
            override fun onSuccess(response: Response<*>) {
                try {
                    isShowSwipeRefreshLayout.value = false
                    Log.e("EmployeModel", "data" + "Under")

                    val pojoNetworkResponse = RetrofitRequest.checkForResponseCode(response.code())
                    when {
                        pojoNetworkResponse.isSuccess && null != response.body() -> {

                            val pojoAlert = response.body() as PojoAlert
                            isAlertData.value = pojoAlert.alerts
                            successMessage.value = "Success"
                        }

                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(t: Throwable) {
                isShowSwipeRefreshLayout.value = false

                RetrofitRequest.getRetrofitError(t)

            }
        }))
    }

    fun onGetAlertSuccess() = isAlertData


}