package com.app.transport.repository.models

data class Error(val statusCode: String, val error: String, val message: String)