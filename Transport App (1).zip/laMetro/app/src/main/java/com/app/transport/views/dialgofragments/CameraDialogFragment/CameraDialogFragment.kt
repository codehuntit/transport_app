package com.app.transport.views.dialgofragments.CameraDialogFragment

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.net.toFile
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.devstory.base.utils.MarshMallowPermissions
import com.devstory.base.views.fragments.BasePictureOptionsFragment
import com.app.transport.R
import com.app.transport.base.BaseAppCompactActivity
import com.app.transport.base.BaseDialogFragment
import com.app.transport.utils.GeneralFunctions
import kotlinx.android.synthetic.main.dialog_fragment_camera.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

typealias LumaListener = (luma: Double) -> Unit

class CameraDialogFragment : BaseDialogFragment() {

    companion object {
        const val REQUEST_CODE_CAMERA_CODES_DIALOG_FRAGMENT = 432
        private const val TAG = "CameraFragment"
        private const val RATIO_4_3_VALUE = 4.0 / 3.0
        private const val RATIO_16_9_VALUE = 16.0 / 9.0
        private const val KEY_EVENT_ACTION = "key_event_action"
        private const val KEY_EVENT_EXTRA = "key_event_extra"
        private const val BUNDLE_FROM = "from"
        const val BUNDLE_TAKE_ID = "takeID"
        const val BUNDLE_TAKE_NORMAL = "takeNormal"

        fun newInstance(from: String): CameraDialogFragment {
            val takePhotosFragment = CameraDialogFragment()
            val bundle = Bundle()
            bundle.putString(BUNDLE_FROM, from)
            takePhotosFragment.arguments = bundle

            return takePhotosFragment
        }
    }

    var photoFile: File? = null
    var mFRom = ""
    private val mMarshMallowPermissions by lazy {
        MarshMallowPermissions(this)
    }

    private val mDisplayManager by lazy {
        requireContext().getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    }

    /** Blocking camera operations are performed using this executor */
    private val mCameraExecutor: ExecutorService by lazy {
        Executors.newSingleThreadExecutor()
    }

    private val mLocalBroadcastManager: LocalBroadcastManager by lazy {
        LocalBroadcastManager.getInstance(requireContext())
    }

    private var mDisplayId: Int = -1
    private var mLensFacing: Int = CameraSelector.LENS_FACING_BACK
    private var mPreview: Preview? = null
    private var mImageCapture: ImageCapture? = null
    private var mImageAnalyzer: ImageAnalysis? = null
    private var mCamera: Camera? = null
    private var mCameraProvider: ProcessCameraProvider? = null


    override val isFullScreenDialog: Boolean
        get() = true
    override val layoutId: Int
        get() = R.layout.dialog_fragment_camera

    override fun init() {

        // Get arguments
        mFRom = arguments?.getString(BUNDLE_FROM).toString()


        // Check for permissions
        if (mMarshMallowPermissions.isCameraPermission) {
            startCamera()
        } else {
            mMarshMallowPermissions.reqPermissionsForCameraCapture(true)
        }

        // Set OnClickListener
//        ivCapture.setOnClickListener(this)


        ivCapture.setOnClickListener {
            takePhoto()

        }
        ivRotate.setOnClickListener {
            switchCamera()

        }
        ivDone.setOnClickListener {
            if (targetFragment != null) {
                targetFragment!!.onActivityResult(
                    targetRequestCode,
                    Activity.RESULT_OK,
                    Intent().putExtra(
                        BasePictureOptionsFragment.INTENT_EXTRAS_IMAGE,
                        photoFile!!.absolutePath
                    )
                )
            }
            dismiss()


        }
        ivCancel.setOnClickListener {
            dismiss()

        }

        setUpCamera()
    }


    private fun popBackFragment() {
        (requireContext() as BaseAppCompactActivity).onBackPressed()
    }

    private fun startCamera() {
        // Set up the intent filter that will receive events from our main activity
        val filter = IntentFilter().apply { addAction(KEY_EVENT_ACTION) }
        mLocalBroadcastManager.registerReceiver(volumeDownReceiver, filter)

        // Every time the orientation of device changes, update rotation for use cases
        mDisplayManager.registerDisplayListener(displayListener, null)

        // Wait for the views to be properly laid out
        viewFinder.post {

            // Keep track of the display in which this view is attached
            mDisplayId = viewFinder.display.displayId

            // Set up the camera and its use cases
            setUpCamera()
        }
    }

    private fun switchCamera() {
        // Disable the button until the camera is set up

        // Listener for button used to switch cameras. Only called if the button is enabled
        mLensFacing = if (CameraSelector.LENS_FACING_FRONT == mLensFacing) {
            CameraSelector.LENS_FACING_BACK
        } else {
            CameraSelector.LENS_FACING_FRONT
        }
        // Re-bind use cases to update selected camera
        bindCameraUseCases()
    }

    private fun takePhoto() {

        // Create output file to hold the image
        photoFile = GeneralFunctions.createFile(
            requireContext()
        )
        // Setup image capture metadata
        val metadata = ImageCapture.Metadata().apply {

            // Mirror image when using the front camera
            isReversedHorizontal = mLensFacing == CameraSelector.LENS_FACING_FRONT
        }

        // Create output options object which contains file + metadata
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile!!)
            .setMetadata(metadata)
            .build()

        // Setup image capture listener which is triggered after photo has been taken
        mImageCapture?.takePicture(
            outputOptions, mCameraExecutor, object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Log.e(TAG, "Photo capture failed: ${exc.message}", exc)
                }


                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val savedUri = output.savedUri ?: Uri.fromFile(photoFile)

                    Log.d(TAG, "Photo capture succeeded: $savedUri")


                    // Update the gallery thumbnail with latest picture taken


                    // Implicit broadcasts will be ignored for devices running API level >= 24
                    // so if you only target API level 24+ you can remove this statement
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
                        requireActivity().sendBroadcast(
                            Intent(android.hardware.Camera.ACTION_NEW_PICTURE, savedUri)
                        )
                    }
                    GlobalScope.launch {

                        withContext(Dispatchers.Main) {
                            ivDone.visibility = View.VISIBLE
                            ivImage.visibility = View.VISIBLE
//                            viewFinder.visibility = View.GONE
                            ivCancel.visibility = View.VISIBLE
//                            ivCapture.visibility = View.GONE
                            setUpCamera()


                            ivImage.setImageURI(Uri.fromFile(photoFile))

                        }

                    }

                    // If the folder selected is an external media directory, this is
                    // unnecessary but otherwise other apps will not be able to access our
                    // images unless we scan them using [MediaScannerConnection]
                    val mimeType = MimeTypeMap.getSingleton()
                        .getMimeTypeFromExtension(savedUri.toFile().extension)
                    MediaScannerConnection.scanFile(
                        context,
                        arrayOf(savedUri.toFile().absolutePath),
                        arrayOf(mimeType)
                    ) { _, uri ->
                        Log.d(
                            TAG,
                            "Image capture scanned into media store: $uri"
                        )
                    }

                }

            })

    }

    fun finish() {

    }

    /** Volume down button receiver used to trigger shutter */
    private val volumeDownReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.getIntExtra(
                KEY_EVENT_EXTRA,
                KeyEvent.KEYCODE_UNKNOWN
            )) {
                // When the volume down button is pressed, simulate a shutter button click
                KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    takePhoto()
                }
            }
        }
    }

    /**
     * We need a display listener for orientation changes that do not trigger a configuration
     * change, for example if we choose to override config change in manifest or for 180-degree
     * orientation changes.
     */
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) = view?.let { view ->
            if (displayId == this@CameraDialogFragment.mDisplayId) {
                Log.d(TAG, "Rotation changed: ${view.display.rotation}")
                mImageCapture?.targetRotation = view.display.rotation
                mImageAnalyzer?.targetRotation = view.display.rotation
            }
        } ?: Unit
    }

    /** Initialize CameraX, and prepare to bind the camera use cases  */
    private fun setUpCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(requireContext())
        cameraProviderFuture.addListener(Runnable {

            // CameraProvider
            mCameraProvider = cameraProviderFuture.get()

            // Select lensFacing depending on the available cameras
            if (mFRom == BasePictureOptionsFragment.BUNDLE_TAKE_ID) {
                CameraSelector.LENS_FACING_BACK
            } else {
                CameraSelector.LENS_FACING_FRONT
            }
            /*mLensFacing = when {
                hasBackCamera() -> CameraSelector.LENS_FACING_BACK
                hasFrontCamera() -> CameraSelector.LENS_FACING_FRONT
                else -> throw IllegalStateException("Back and front camera are unavailable")
            }*/

            // Enable or disable switching between cameras

            // Build and bind the camera use cases
            bindCameraUseCases()
        }, ContextCompat.getMainExecutor(requireContext()))

    }

    /** Declare and bind preview, capture and analysis use cases */
    private fun bindCameraUseCases() {

        // Get screen metrics used to setup camera for full screen resolution
        val metrics = DisplayMetrics().also { viewFinder.display.getRealMetrics(it) }
        Log.d(
            TAG,
            "Screen metrics: ${metrics.widthPixels} x ${metrics.heightPixels}"
        )

        val screenAspectRatio = aspectRatio(metrics.widthPixels, metrics.heightPixels)
        Log.d(TAG, "Preview aspect ratio: $screenAspectRatio")

        val rotation = viewFinder.display.rotation

        // CameraProvider
        val cameraProvider = mCameraProvider
            ?: throw IllegalStateException("Camera initialization failed.")

        // CameraSelector
        val cameraSelector = CameraSelector.Builder().requireLensFacing(mLensFacing).build()

        // Preview
        mPreview = Preview.Builder()
            // We request aspect ratio but no resolution
            .setTargetAspectRatio(screenAspectRatio)
            // Set initial target rotation
            .setTargetRotation(rotation)
            .build()

        // ImageCapture
        mImageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            // We request aspect ratio but no resolution to match preview config, but letting
            // CameraX optimize for whatever specific resolution best fits our use cases
            .setTargetAspectRatio(screenAspectRatio)
            // Set initial target rotation, we will have to call this again if rotation changes
            // during the lifecycle of this use case
            .setTargetRotation(rotation)
            .build()

        // ImageAnalysis
        mImageAnalyzer = ImageAnalysis.Builder()
            // We request aspect ratio but no resolution
            .setTargetAspectRatio(screenAspectRatio)
            // Set initial target rotation, we will have to call this again if rotation changes
            // during the lifecycle of this use case
            .setTargetRotation(rotation)
            .build()
            // The analyzer can then be assigned to the instance
            .also {
                it.setAnalyzer(mCameraExecutor, LuminosityAnalyzer { luma ->
                    // Values returned from our analyzer are passed to the attached listener
                    // We log image analysis results here - you should do something useful
                    // instead!
//                    Log.d(TAG, "Average luminosity: $luma")
                })
            }

        // Must unbind the use-cases before rebinding them
        cameraProvider.unbindAll()

        try {
            // A variable number of use-cases can be passed here -
            // camera provides access to CameraControl & CameraInfo
            mCamera = cameraProvider.bindToLifecycle(
                this, cameraSelector, mPreview, mImageCapture, mImageAnalyzer
            )

            // Attach the viewfinder's surface provider to preview use case
            mPreview?.setSurfaceProvider(viewFinder.createSurfaceProvider(mCamera?.cameraInfo))
        } catch (exc: Exception) {
            Log.e(TAG, "Use case binding failed", exc)
        }
    }

    /**
     *  [androidx.camera.core.ImageAnalysisConfig] requires enum value of
     *  [androidx.camera.core.AspectRatio]. Currently it has values of 4:3 & 16:9.
     *
     *  Detecting the most suitable ratio for dimensions provided in @params by counting absolute
     *  of preview ratio to one of the provided values.
     *
     *  @param width - preview width
     *  @param height - preview height
     *  @return suitable aspect ratio
     */
    private fun aspectRatio(width: Int, height: Int): Int {
        val previewRatio = Math.max(width, height).toDouble() / Math.min(width, height)
        if (Math.abs(previewRatio - RATIO_4_3_VALUE) <= Math.abs(previewRatio - RATIO_16_9_VALUE)) {
            return AspectRatio.RATIO_4_3
        }
        return AspectRatio.RATIO_16_9
    }

    /** Enabled or disabled a button to switch cameras depending on the available cameras */


    /** Returns true if the device has an available back camera. False otherwise */
    private fun hasBackCamera(): Boolean {
        return mCameraProvider?.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) ?: false
    }

    /** Returns true if the device has an available front camera. False otherwise */
    private fun hasFrontCamera(): Boolean {
        return mCameraProvider?.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) ?: false
    }

    /**
     * Our custom image analysis class.
     *
     * <p>All we need to do is override the function `analyze` with our desired operations. Here,
     * we compute the average luminosity of the image by looking at the Y plane of the YUV frame.
     */
    private class LuminosityAnalyzer(listener: LumaListener? = null) : ImageAnalysis.Analyzer {
        private val frameRateWindow = 8
        private val frameTimestamps = ArrayDeque<Long>(5)
        private val listeners = ArrayList<LumaListener>().apply { listener?.let { add(it) } }
        private var lastAnalyzedTimestamp = 0L
        var framesPerSecond: Double = -1.0
            private set

        /**
         * Used to add listeners that will be called with each luma computed
         */
        fun onFrameAnalyzed(listener: LumaListener) = listeners.add(listener)

        /**
         * Helper extension function used to extract a byte array from an image plane buffer
         */
        private fun ByteBuffer.toByteArray(): ByteArray {
            rewind()    // Rewind the buffer to zero
            val data = ByteArray(remaining())
            get(data)   // Copy the buffer into a byte array
            return data // Return the byte array
        }

        /**
         * Analyzes an image to produce a result.
         *
         * <p>The caller is responsible for ensuring this analysis method can be executed quickly
         * enough to prevent stalls in the image acquisition pipeline. Otherwise, newly available
         * images will not be acquired and analyzed.
         *
         * <p>The image passed to this method becomes invalid after this method returns. The caller
         * should not store external references to this image, as these references will become
         * invalid.
         *
         * @param image image being analyzed VERY IMPORTANT: Analyzer method implementation must
         * call image.close() on received images when finished using them. Otherwise, new images
         * may not be received or the camera may stall, depending on back pressure setting.
         *
         */
        override fun analyze(image: ImageProxy) {
            // If there are no listeners attached, we don't need to perform analysis
            if (listeners.isEmpty()) {
                image.close()
                return
            }

            // Keep track of frames analyzed
            val currentTime = System.currentTimeMillis()
            frameTimestamps.push(currentTime)

            // Compute the FPS using a moving average
            while (frameTimestamps.size >= frameRateWindow) frameTimestamps.removeLast()
            val timestampFirst = frameTimestamps.peekFirst() ?: currentTime
            val timestampLast = frameTimestamps.peekLast() ?: currentTime
            framesPerSecond = 1.0 / ((timestampFirst - timestampLast) /
                    frameTimestamps.size.coerceAtLeast(1).toDouble()) * 1000.0

            // Analysis could take an arbitrarily long amount of time
            // Since we are running in a different thread, it won't stall other use cases

            lastAnalyzedTimestamp = frameTimestamps.first

            // Since format in ImageAnalysis is YUV, image.planes[0] contains the luminance plane
            val buffer = image.planes[0].buffer

            // Extract image data from callback object
            val data = buffer.toByteArray()

            // Convert the data into an array of pixel values ranging 0-255
            val pixels = data.map { it.toInt() and 0xFF }

            // Compute average luminance for the image
            val luma = pixels.average()

            // Call all listeners with new value
            listeners.forEach { it(luma) }

            image.close()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            MarshMallowPermissions.RQ_CAMERA_CAPTURE_PERMISSION ->
                if (PackageManager.PERMISSION_GRANTED == grantResults[0]) {
                    startCamera()
                } else {
                    Toast.makeText(
                        requireContext(), R.string.androidx_camera_default_config_provider,
                        Toast.LENGTH_LONG
                    ).show()
                    false

                }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()

        // Shut down our background executor
        mCameraExecutor.shutdown()

        // Unregister the broadcast receivers and listeners
        mLocalBroadcastManager.unregisterReceiver(volumeDownReceiver)
        mDisplayManager.unregisterDisplayListener(displayListener)
    }


}