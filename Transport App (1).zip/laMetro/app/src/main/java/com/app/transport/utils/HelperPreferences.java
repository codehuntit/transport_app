package com.app.transport.utils;

import android.content.Context;
import android.content.SharedPreferences;


public class HelperPreferences {

    private static final String PREFERENCE_NAME = "helper_preferences";

    private static HelperPreferences instance;

    private SharedPreferences mSharedPreferences;

    /**
     * Private Constructor, initializing shared preferences
     *
     * @param context - Context to initialize preferences
     */
    private HelperPreferences(Context context) {
        mSharedPreferences = context.getSharedPreferences(PREFERENCE_NAME,
                Context.MODE_PRIVATE);
    }

    /**
     * Method to Get instance of Singleton {@code HelperPreferences } class
     *
     * @param context - Context of the calling activity/application
     * @return - Instance of HelperPreferences
     */
    public static HelperPreferences get(final Context context) {
        if (instance == null) {
            instance = new HelperPreferences(context);
        }
        return instance;
    }

    /**
     * Method to store {@code String} value corresponding to a key
     *
     * @param key   - Key
     * @param value - String value to be stored
     */
    public void saveString(final String key, final String value) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public void removeValue(final String key) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.remove(key);
        editor.commit();
    }

    /**
     * Method to store {@code int} value corresponding to a key
     *
     * @param key   - Key
     * @param value - int value to be stored
     */
    public void saveInt(final String key, final int value) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putInt(key, value);
        editor.apply();
    }

    /**
     * Method to store {@code long} value corresponding to a key
     *
     * @param key   - Key
     * @param value - long value to be stored
     */
    public void saveLong(final String key, final long value) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putLong(key, value);
        editor.apply();
    }

    /**
     * Method to store {@code boolean} value corresponding to a key
     *
     * @param key   - Key
     * @param value - boolean value to be stored
     */
    public void saveBoolean(final String key, final boolean value) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    /**
     * Method to store {@code float} value corresponding to a key
     *
     * @param key   - Key
     * @param value - Float value to be stored
     */
    public void saveFloat(final String key, final float value) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putFloat(key, value);
        editor.apply();
    }

    /**
     * Method to clear all the shared preferences stored, this will be helpful in
     * scenarios like logout
     */
    public void clear() {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.clear();
        editor.apply();
        editor.commit();
    }

    /**
     * Method to get {@code String} value from preferences for a given Key
     *
     * @param key - Key to fetch the value
     * @return - Actual value, returns null if not found
     */
    public String getString(final String key) {
        return mSharedPreferences.getString(key, null);
    }

    public String getString(final String key, final String defaultValue) {
        return mSharedPreferences.getString(key, defaultValue);
    }

    /**
     * Method to get {@code long} value from preferences for a given Key
     *
     * @param key - Key to fetch the value
     * @return - Actual value, returns 0 if not found
     */
    public long getLong(final String key) {
        return mSharedPreferences.getLong(key, 0L);
    }

    /**
     * Method to get {@code int} value from preferences for a given Key
     *
     * @param key - Key to fetch the value
     * @return - Actual value, returns 0 if not found
     */
    public int getInt(final String key) {
        return mSharedPreferences.getInt(key, 0);
    }

    /**
     * Method to get {@code float} value from preferences for a given Key
     *
     * @param key - Key to fetch the value
     * @return - Actual value, returns 0 if not found
     */
    public double getFloat(final String key) {
        return mSharedPreferences.getFloat(key, 0.0F);
    }

    /**
     * Method to get {@code boolean} value from preferences for a given Key
     *
     * @param key - Key to fetch the value
     * @return - Actual value, returns false if not found
     */
    public boolean getBoolean(final String key, final boolean defaultValue) {
        return mSharedPreferences.getBoolean(key, defaultValue);
    }

    public String getDeviceToken(final String defaultValue) {
        return mSharedPreferences.getString(Constants.Keys.DEVICE_TOKEN, defaultValue);
    }

    public void saveDeviceToken(final String value) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putString(Constants.Keys.DEVICE_TOKEN, value);
        editor.apply();
    }

    public void saveSignUpDate(final String value) {
        saveString(Constants.Keys.CREATED_DATE, value);
    }

    public String getSignUpDate() {
        return getString(Constants.Keys.CREATED_DATE);
    }

    public void saveUserId(String value) {
        saveString(Constants.Keys.USER_ID, value);
    }

    public String getUserId() {
        return getString(Constants.Keys.USER_ID);
    }

    public void saveUserToken(String value) {
        saveString(Constants.Keys.USER_TOKEN, value);
    }

    public void saveUserName(String value) {
        saveString(Constants.Keys.USER_NAME, value);
    }

    public void saveUserEmail(String value) {
        saveString(Constants.Keys.USER_EMAIL, value);
    }

    public void saveUserPic(String value) {
        saveString(Constants.Keys.USER_PIC, value);
    }

    public String getUserToken() {
        return getString(Constants.Keys.USER_TOKEN);
    }

    public String getUserName() {
        return getString(Constants.Keys.USER_NAME);
    }

    public String getUserProfilePic() {
        return getString(Constants.Keys.USER_PIC);
    }

    public String getUser̥Email() {
        return getString(Constants.Keys.USER_EMAIL);
    }

    public String get_Session_id() {
        return getString(Constants.Keys.Save_Session_id);
    }

    public void save_Session_id(String value) {
        saveString(Constants.Keys.Save_Session_id, value);
    }

    public String get_access_token() {
        return getString(Constants.Keys.access_token);
    }

    public void save_access_token(String value) {
        saveString(Constants.Keys.access_token, value);
    }    public String get_refresh_token() {
        return getString(Constants.Keys.refresh_token);
    }

    public void save_refresh_token(String value) {
        saveString(Constants.Keys.refresh_token, value);
    }
     public String get_onapalied_job() {
        return getString(Constants.Keys.onapalied_job);
    }

    public void save_onapalied_job(String value) {
        saveString(Constants.Keys.onapalied_job, value);
    }


    public String get_UId() {
        return getString(Constants.Keys.UId);
    }

    public void save_UId(String value) {
        saveString(Constants.Keys.UId, value);
    }  public String get_service_staff_id() {
        return getString(Constants.Keys.service_staff_id);
    }

    public void save_service_staff_id(String value) {
        saveString(Constants.Keys.service_staff_id, value);
    }
    public String get_Sinature() {
        return getString(Constants.Keys.Sinature);
    }

    public void save_Sinature(String value) {
        saveString(Constants.Keys.Sinature, value);
    }

    public String getDeviceID() {
        return getString(Constants.Keys.deviceId);
    }

    public void saveDeviceID(String value) {
        saveString(Constants.Keys.deviceId, value);
    }

    public void saveUser(String userId, String userToken) {
        saveUserId(userId);
        saveUserToken(userToken);
    }
    public String getChatUser() {
        return getString(Constants.Keys.USER_CHAT);
    }

    public void saveChatUser(String value) {
        saveString(Constants.Keys.USER_CHAT, value);
    }


}
