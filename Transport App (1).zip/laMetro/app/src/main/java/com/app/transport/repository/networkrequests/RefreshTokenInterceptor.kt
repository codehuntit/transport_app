package com.app.transport.repository.networkrequests

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.app.transport.utils.ApplicationGlobal
import okhttp3.FormBody
import okhttp3.Interceptor
import okhttp3.Response
import org.greenrobot.eventbus.EventBus
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets.UTF_8


class RefreshTokenInterceptor : Interceptor {

    private var mRefreshedAccessToken = ""
    private var mRefreshedRefreshToken = ""

    override fun intercept(chain: Interceptor.Chain): Response {

        val originalRequest = chain.request()
        val modiedRequestBuilder = originalRequest.newBuilder()

        val hasAuthorization = originalRequest.headers["Authorization"]

        if (hasAuthorization != null && mRefreshedAccessToken != "") {
            modiedRequestBuilder.removeHeader("Authorization")
            modiedRequestBuilder.addHeader(
                "Authorization", "Bearer " +
                        mRefreshedAccessToken
            )
        }

        val mRefreshToken = originalRequest.headers["RefreshTokenAPI"]
        var mRefreshedRefreshTokenApp = originalRequest.headers.get("RefreshToken")
        if (mRefreshedRefreshTokenApp != null) {
            modiedRequestBuilder.removeHeader("RefreshToken")
        }

        var response = chain.proceed(modiedRequestBuilder.build())
        if (hasAuthorization != null && mRefreshedRefreshTokenApp != null &&
            mRefreshedRefreshTokenApp != "" && (response.code == 401 || response.code == 403)
        ) {
            mRefreshedRefreshTokenApp.trim()
            if (mRefreshedRefreshToken != "") {
                mRefreshedRefreshTokenApp = mRefreshedRefreshToken.trim()
            }

            val formBody = FormBody.Builder()
                .add("client_id", WebConstants.ACTION_CLIENT_ID)
                .add("grant_type", "refresh_token")
                .add("refresh_token", mRefreshedRefreshTokenApp)
                .add("client_secret", WebConstants.ACTION_CLIENT_SECRET)
                .build()

            val tokenRequestBuilder = originalRequest.newBuilder()
            tokenRequestBuilder.url(WebConstants.ACTION_REFRESH_TOEKN_BASE_URL)
                .addHeader("Content-Type", "application/x-www-form-urlencoded").post(formBody)

            tokenRequestBuilder.removeHeader("Authorization")

            val tokenResponse = chain.proceed(tokenRequestBuilder.build())

            if (tokenResponse.code == 200) {
                val tokenResponseBody = tokenResponse.body
                val contentLength = tokenResponseBody?.contentLength()
                val source = tokenResponseBody?.source()
                source?.request(Long.MAX_VALUE)
                val buffer = source?.buffer
                val contentType = tokenResponseBody?.contentType()
                val charset: Charset = contentType?.charset(UTF_8) ?: UTF_8


                if (contentLength != 0L) {

                    val mRefreshTokenString = buffer?.clone()?.readString(charset)
                    val mRefreshTokenJson = JsonParser().parse(mRefreshTokenString)
                    val mRefreshTokenObject: JsonObject = mRefreshTokenJson.asJsonObject


                    var accessToken = mRefreshTokenObject.get("access_token").toString()
                    var refreshToken = mRefreshTokenObject.get("refresh_token").toString()

                    // access token
                    val d = accessToken.removePrefix("\"")
                    val e = d.removeSuffix("\"")
                    val accessTokenPass = "Bearer $e"
                    accessToken = e


                    // refresh token
                    val f = refreshToken.removePrefix("\"")
                    val g = f.removeSuffix("\"")
                    refreshToken = g

                    //Call Original Request With modified Token
                    val modiedRequestBuilderWithNewToken = originalRequest.newBuilder()
                    modiedRequestBuilderWithNewToken.removeHeader("Authorization")
                    modiedRequestBuilderWithNewToken.addHeader("Authorization", accessTokenPass)

                    response = chain.proceed(modiedRequestBuilderWithNewToken.build())

                    // save data in preference
                    val app = ApplicationGlobal()
                    app.onSaveInPrefrence(accessToken, refreshToken)

                    // save data in global parameter
                    mRefreshedAccessToken = accessToken
                    mRefreshedRefreshToken = refreshToken
                }

            } else {
                // logout  event bus send
                EventBus.getDefault().post("logout")
            }
        }


        // When Refresh Token API Hit
        if (mRefreshToken != null && response.code == 200) {

            val tokenResponseBody = response.body
            val contentLength = tokenResponseBody?.contentLength()
            val source = tokenResponseBody?.source()
            source?.request(Long.MAX_VALUE)
            val buffer = source?.buffer

            val contentType = tokenResponseBody?.contentType()
            val charset: Charset = contentType?.charset(UTF_8) ?: UTF_8

            if (contentLength != 0L) {
                val mRefreshTokenString = buffer?.clone()?.readString(charset)
                val mRefreshTokenJson = JsonParser().parse(mRefreshTokenString)
                val mRefreshTokenObject: JsonObject = mRefreshTokenJson.asJsonObject
                var accessToken = mRefreshTokenObject.get("access_token").toString()
                var refreshToken = mRefreshTokenObject.get("refresh_token").toString()


                val d = accessToken.removePrefix("\"")
                val e = d.removeSuffix("\"")
                accessToken = e

                val f = refreshToken.removePrefix("\"")
                val g = f.removeSuffix("\"")
                refreshToken = g

                // save data in preference
                val app = ApplicationGlobal()
                app.onSaveInPrefrence(accessToken, refreshToken)

                mRefreshedAccessToken = accessToken
                mRefreshedRefreshToken = refreshToken
            }
        }

        return response
    }
}