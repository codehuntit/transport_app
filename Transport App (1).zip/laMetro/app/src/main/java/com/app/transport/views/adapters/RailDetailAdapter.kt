package com.app.transport.views.adapters

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.transport.R
import com.app.transport.base.inflate
import com.app.transport.repository.models.rail.RailDirection
import com.app.transport.repository.models.rail.RailStop
import com.app.transport.repository.models.rail.Stop
import com.app.transport.views.activities.RailPredictionActivity
import kotlinx.android.synthetic.main.row_rail.view.*
import java.util.ArrayList

class RailDetailAdapter(var context: Activity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var mTrainList = ArrayList<RailStop>()
var lineColor=""

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ListViewHolder(parent.inflate(R.layout.row_rail))
    }

    override fun getItemCount(): Int {
        return mTrainList.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {

        holder.itemView.setOnClickListener {
            val intent = Intent(context, RailPredictionActivity::class.java)
            intent.putExtra("stopID",mTrainList[i].id)
            intent.putExtra("stopName",mTrainList[i].name)
            intent.putExtra("lineColor",lineColor)
            context!!. startActivity(intent)
        }
        holder.itemView.ivCircle.getBackground().setTint(Color.parseColor("#" +lineColor));
        holder.itemView.view.setBackgroundColor(Color.parseColor("#" +lineColor));
holder.itemView.tvName.text = mTrainList[i].name
        if(i==mTrainList.size-1)
        {
            holder.itemView.view.visibility= View.GONE
        }else
        {
            holder.itemView.view.visibility= View.VISIBLE
        }
    }

    fun updateData(stops: List<RailStop>, color: String) {
        lineColor = color
        mTrainList.clear()
        mTrainList.addAll(stops)
        notifyDataSetChanged()
    }


    private inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
}