package com.app.transport.repository.models.bus

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


data class PojoBusRoutesList(
    val `data`: Data = Data(),
    val route: String="",
    val success: Boolean=false
)

data class Data(
    val agencyKey: String="",
    val routes: List<Route> = mutableListOf()
)

@Parcelize
data class Route(
    val directions: List<DirectionBus> = mutableListOf(),
    val extent: Extent =Extent(),
    val id: String="",
    val longName: String="",
    val name: String="",
    val shapes: List<Shape>,
    val shortName: String="",

    val type: String=""
) : Parcelable

@Parcelize
data class DirectionBus(
    val headsigns: List<String> = mutableListOf(),
    val id: String="",
    val stops: ArrayList<Stops> = ArrayList(),
    val title: String=""
) : Parcelable

@Parcelize
data class Extent(
    val maxLat: Double=0.0,
    val maxLon: Double=0.0,
    val minLat: Double=0.0,
    val minLon: Double=0.0
): Parcelable

@Parcelize
data class Shape(
    val directionId: String="",
    val headsign: String="",
    val locs: List<Loc>,
    val minor: Boolean=false,
    val shapeId: String="",
    val tripPatternId: String=""
) : Parcelable

@Parcelize
data class Stops(
    val code: Int,
    val id: String="",
    val lat: Double=0.0,
    val lon: Double=0.0,
    val minor: Boolean=false,
    val name: String=""
) : Parcelable

@Parcelize
data class Loc(
    val lat: Double=0.0,
    val lon: Double=0.0
) : Parcelable