package com.app.transport.repository.models.rail

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

data class PojoMetroLine
    (
    val `data`: RailsData = RailsData(),
    val route: String = "",
    val success: Boolean = false
)

data class RailsData(
    val agencyKey: String = "",
    val routes: List<RailRoute> = mutableListOf()
)

@Parcelize
data class RailRoute(
    val color: String = "",
    val directions: List<RailDirection> = mutableListOf(),
    val extent: Extent = Extent(),
    val id: String = "",
    val longName: String = "",
    val name: String = "",
    val shapes: List<Shape> = mutableListOf(),
    val shortName: String = "",
    val textColor: String = "",
    val type: String = ""
) : Parcelable

@Parcelize
data class RailDirection(
    val headsigns: List<String> = mutableListOf(),
    val id: String = "",
    val stops: ArrayList<RailStop> = ArrayList(),
    val title: String = ""
) : Parcelable

@Parcelize
data class Extent(
    val maxLat: Double = 0.0,
    val maxLon: Double = 0.0,
    val minLat: Double = 0.0,
    val minLon: Double = 0.0
) : Parcelable

@Parcelize
data class Shape(
    val directionId: String = "",
    val headsign: String = "",
    val locs: List<Loc> = mutableListOf(),
    val minor: Boolean = false,
    val shapeId: String = "",
    val tripPatternId: String = ""
) : Parcelable

@Parcelize
data class RailStop(
    val code: Int= 0,
    val id: String = "",
    val lat: Double = 0.0,
    val lon: Double = 0.0,
    val minor: Boolean = false,
    val name: String = ""
) : Parcelable

@Parcelize
data class Loc(
    val lat: Double = 0.0,
    val lon: Double = 0.0
) : Parcelable