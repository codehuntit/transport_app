package com.app.transport.viewmodels

import android.app.Application
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.app.transport.repository.interactors.GetEmploeyeIntrector
import com.app.transport.repository.networkrequests.NetworkRequestCallbacks
import com.app.transport.repository.networkrequests.RetrofitRequest
import com.example.mvvmnewdemo.WithApiExample.model.EmployeData
import com.example.mvvmnewdemo.WithApiExample.model.EmployeRespnseModel
import retrofit2.Response
import java.lang.Exception

class EmployeViewModel(application: Application) : BaseViewModel(application) {
    private val getEmployes: GetEmploeyeIntrector? = null
    private val memployeviewModel by lazy { GetEmploeyeIntrector() }
    private val emplyeList = MutableLiveData<List<EmployeData>>()

    fun getEnployeedata() {
        isShowSwipeRefreshLayout.value = true
        mCompositeDisposable.add(memployeviewModel.ongetEmployedata(object :
            NetworkRequestCallbacks {
            override fun onSuccess(response: Response<*>) {
                try {
                    isShowSwipeRefreshLayout.value = false
                    Log.e("EmployeModel", "data" + "Under")

                    val pojoNetworkResponse = RetrofitRequest.checkForResponseCode(response.code())
                    when {
                        pojoNetworkResponse.isSuccess && null != response.body() -> {

                            val pojoServiceRequest = response.body() as EmployeRespnseModel
                            emplyeList.value = pojoServiceRequest.getmData()
                            successMessage.value = "Success"
                        }

                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onError(t: Throwable) {
                isShowSwipeRefreshLayout.value = false

                RetrofitRequest.getRetrofitError(t)

            }
        }))
    }

    fun ongetEmployeList() = emplyeList


}