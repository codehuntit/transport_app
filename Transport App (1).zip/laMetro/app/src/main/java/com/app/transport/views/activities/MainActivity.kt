package com.app.transport.views.activities

import android.graphics.Color
import android.os.Handler
import android.view.View
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.FragmentTransaction
import com.app.transport.R
import com.app.transport.base.BaseActivity
import com.app.transport.databinding.ActivityMainBinding
import com.app.transport.viewmodels.BaseViewModel
import com.app.transport.views.fragments.*
import com.c9v.c9vUsers.controller.utills.PermissionCheckUtil


class MainActivity : BaseActivity(), View.OnClickListener {
    var binding: ActivityMainBinding? = null

    override fun getContentId(): Int {
        return R.layout.activity_main
    }

    override val viewModel: BaseViewModel?
        get() = null

    override fun init() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        PermissionCheckUtil.create(this, object :
            PermissionCheckUtil.onPermissionCheckCallback {
            override fun onPermissionSuccess() {


            }
        })
        binding!!.liFav.setOnClickListener(this)
        binding!!.liBus.setOnClickListener(this)
        binding!!.liTrain.setOnClickListener(this)
        binding!!.liMaps.setOnClickListener(this)
        binding!!.liAlert.setOnClickListener(this)

        // load fragment
        val fm = supportFragmentManager
        val fragment = FavroiteFragment()
        val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.flHome, fragment)
            .addToBackStack(null)
        fragmentTransaction.commit()
    }

    override fun observeProperties() {
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.liFav -> {

                val fm = supportFragmentManager
                val fragment = FavroiteFragment()
                val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.flHome, fragment)
                    .addToBackStack(null)
                fragmentTransaction.commit()
                binding!!.liFav.setBackgroundColor(Color.parseColor("#FF0277BD"))
                binding!!.liBus.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liTrain.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liMaps.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liAlert.setBackgroundColor(Color.parseColor("#D2000000"))
            }
            R.id.liBus -> {
                val fm = supportFragmentManager
                val fragment = BusFragment()
                val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.flHome, fragment)
                    .addToBackStack(null)
                fragmentTransaction.commit()
                binding!!.liFav.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liBus.setBackgroundColor(Color.parseColor("#FF0277BD"))
                binding!!.liTrain.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liMaps.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liAlert.setBackgroundColor(Color.parseColor("#D2000000"))
            }
            R.id.liTrain -> {
                val fm = supportFragmentManager
                val fragment = TrainFragment()
                val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.flHome, fragment)
                    .addToBackStack(null)
                fragmentTransaction.commit()
                binding!!.liFav.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liBus.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liTrain.setBackgroundColor(Color.parseColor("#FF0277BD"))
                binding!!.liMaps.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liAlert.setBackgroundColor(Color.parseColor("#D2000000"))
            }
            R.id.liMaps -> {
                val fm = supportFragmentManager
                val fragment = MapFragment()
                val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.flHome, fragment)
                    .addToBackStack(null)
                fragmentTransaction.commit()
                binding!!.liFav.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liBus.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liTrain.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liMaps.setBackgroundColor(Color.parseColor("#FF0277BD"))
                binding!!.liAlert.setBackgroundColor(Color.parseColor("#D2000000"))
            }
            R.id.liAlert -> {
                val fm = supportFragmentManager
                val fragment = AlertFragment()
                val fragmentTransaction: FragmentTransaction = fm.beginTransaction()
                fragmentTransaction.replace(R.id.flHome, fragment)
                    .addToBackStack(null)
                fragmentTransaction.commit()
                binding!!.liFav.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liBus.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liTrain.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liMaps.setBackgroundColor(Color.parseColor("#D2000000"))
                binding!!.liAlert.setBackgroundColor(Color.parseColor("#FF0277BD"))
            }
        }
    }


}
